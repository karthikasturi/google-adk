# Learner Project Review: Deepak L

**Learner ID:** deepak_l_cfd963  
**Repo:** https://github.com/deepak-l-ios/ecombot-goodleadk-capstone

**Overall Score:** ![score](https://img.shields.io/badge/Score-5.33/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (fail, 2.0/10)
    - The provided `support_agent.py` file contains a highly complex agent with numerous features (tools, RAG, LiteLLM routing, FastMCP, guardrails, etc.) that are far beyond the scope of a 'Basic Support Agent' for Module 1.
    - The `support_agent.py` file imports and references components like `tools/order_tools.py`, `rag/retriever.py`, `routing.py`, and `guardrails.py`, indicating a multi-module implementation rather than a basic v1 agent.
    - The `stt_openrouter.py` file is related to the voice interface (Module 8) and is not relevant to the requirements of Module 1, which focuses solely on a text-based basic agent.
    - There is no clear evidence of a simple, intent-based agent as described for Module 1. The agent appears to be a near-final version of the `Support Agent` from later modules.
    _Suggestions:_
      - For Module 1, create a new, simplified agent file that only includes basic intent recognition and responses, without any tools, RAG, or complex routing. Focus on the `_PERSONA` and `_build_instruction` for simple text-based interactions.
      - Remove all imports and references to tools, RAG, LiteLLM, FastMCP, and guardrails from the Module 1 agent. These features will be added in subsequent modules.
      - Ensure the agent is testable via ADK Web with at least 3 distinct prompt behavior variations (e.g., 'Where is my order?', 'What products do you have?', 'I need help with a return.') that are handled by the agent's prompt knowledge alone.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 9.5/10)
    - The `lookup_product` tool correctly searches mock product data and stores relevant product information in `tool_context.state`.
    - The `get_order_status` tool effectively retrieves order details from mock data, validates order IDs, and persists order and customer information in `tool_context.state`.
    - The `cancel_order` tool handles cancellation logic, including validation, checking non-cancellable statuses, and updating mock order status, while also utilizing session state for 'current' order ID.
    - Both `product_tools.py` and `order_tools.py` include clear docstrings and comments indicating what is stored in `tool_context.state`.
    _Suggestions:_
      - Ensure that the `SESSION_BACKEND` environment variable is consistently used and documented for switching between mock and database modes across all relevant modules.
      - Consider adding more comprehensive unit tests for edge cases and failure scenarios for both `lookup_product` and `cancel_order` tools, especially around invalid inputs and non-cancellable order statuses.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 7.5/10)
    - The `embed_catalog.py` script correctly loads product and FAQ JSON files, and also includes functionality to load and chunk PDF documents, demonstrating a robust approach to knowledge ingestion.
    - The `embed` function in `embed_catalog.py` uses LiteLLM for embeddings, which aligns with the project's goal of using LiteLLM for cost-aware routing and model flexibility.
    - The ChromaDB collection is properly initialized and rebuilt if empty or explicitly requested, ensuring the knowledge base is always up-to-date.
    - The `product_agent.py` instruction explicitly states that the agent should not guess and should use a product lookup tool if available, which implies an intention for RAG grounding, though the RAG integration itself is not directly visible in this agent's code.
    _Suggestions:_
      - While the `embed_catalog.py` sets up the RAG knowledge base, the provided `product_agent.py` does not show explicit integration of this RAG system (e.g., a retriever tool or RAG-specific prompt instructions). Ensure the agent actively queries the ChromaDB for grounded responses.
      - Implement and demonstrate the 'hallucination guard' within the agent's logic. This typically involves checking the relevance or confidence of retrieved documents before generating a response, or explicitly instructing the LLM to state when it cannot find an answer.
      - Add specific test cases (e.g., in `evals/promptfoo.yaml`) that directly verify the agent's ability to retrieve correct information from the RAG knowledge base and gracefully handle unanswerable queries.
- **Implement LiteLLM Model Routing (eComBot v4)** (partial, 6.5/10)
    - The `classify_query` function in `tests/test_routing.py` correctly identifies 'fast-faq' and 'deep-support' categories for various queries, indicating a basic routing mechanism is in place.
    - The test cases in `tests/test_routing.py` cover different query types and confirm that the `classify_query` function returns the expected route categories.
    - The `test_routing_manual.md` file outlines expected model routing for different queries, including a scenario for fallback verification, which is a good step towards testing the LiteLLM integration.
    - The `stt_openrouter.py` file shows an attempt to use OpenRouter for STT, which implies an understanding of integrating external models, but this is not directly related to the LiteLLM routing for the agent's LLM calls.
    _Suggestions:_
      - Implement the actual LiteLLM integration within the agent's LLM calls, using the `classify_query` output to dynamically select `gpt-4o-mini` or `gpt-4o`.
      - Add concrete code examples or a dedicated test file that simulates model failures and verifies the automatic fallback to OpenRouter, as described in `test_routing_manual.md`.
      - Ensure that the LiteLLM configuration includes both OpenAI and OpenRouter providers, and that the model selection logic is applied to the agent's primary LLM calls, not just the STT component.
- **Integrate FastMCP External APIs (eComBot v5)** (pass, 9.5/10)
    - Two FastMCP mock servers (`inventory_server.py` and `orders_server.py`) have been successfully implemented, exposing the required tools.
    - The `check_stock` tool in `inventory_server.py` and `get_order_status`, `get_order_details`, `list_orders`, and `cancel_order_mcp` in `orders_server.py` are correctly defined and return structured data.
    - Error handling for invalid IDs is present in both servers, returning informative messages when a product or order is not found.
    - The `INVENTORY_SEARCH_DELAY_SECONDS` environment variable is used to simulate delays, demonstrating an understanding of how to test for timeouts.
    _Suggestions:_
      - While `INVENTORY_SEARCH_DELAY_SECONDS` is good for simulating timeouts, consider adding similar delay mechanisms or explicit error injection points (e.g., a specific `order_id` that triggers a 500 error) to `orders_server.py` to fully cover API failure simulation for 500 errors as per requirements.
      - Ensure that the `cancel_order_mcp` tool's incomplete return statement (ending with `Please contact support to r`) is fixed to provide a complete and coherent message.
- **Develop Multi-Agent Architecture (eComBot v6)** (pass, 8.5/10)
    - The learner has successfully created separate `sales_agent.py` and `support_agent.py` files, indicating a clear separation of concerns for different agent roles.
    - Both `sales_agent.py` and `support_agent.py` define `LlmAgent` instances with distinct names and descriptions, fulfilling the requirement for specialized agents.
    - The `sales_agent.py` includes a `_REACT_RULES` section in its persona, demonstrating an understanding of the Sales Agent's specific reasoning requirements, even if the full ReAct loop is for a later module.
    - The `support_agent.py` correctly integrates tools like `get_order_status` and `cancel_order`, showing that the M1-M5 work is carried over to the Support Agent.
    _Suggestions:_
      - While the agents are separated, the current submission doesn't explicitly show the 'Orchestrator' agent that classifies intent and delegates tasks. This is a crucial part of the multi-agent architecture and should be implemented to demonstrate the 'Planner–Executor pattern'.
      - To fully validate task delegation and routing, ensure there's a central point (likely the Orchestrator) that directs user queries like 'Where is my order?' to the Support Agent and 'What phone should I buy?' to the Sales Agent.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not include any UI-related files (e.g., `src/ui/app.py` or `demo.py` with UI components).
    - The `requirements.txt` file lists `chainlit>=2.0.0`, which is a UI framework, but its implementation is not visible in the provided code.
    - The `product_agent.py` and `routing.py` files are foundational for agent logic and model routing, but they do not directly contribute to the generative UI aspects.
    - There is no evidence of rich UI components (product cards, order status cards, agent routing trace, RAG source tags, LiteLLM model badge) or real-time streaming in the given files.
    _Suggestions:_
      - Provide the `src/ui/app.py` file or the main application file that defines and renders the Gradio interface.
      - Demonstrate how agent outputs are transformed into structured UI components (e.g., product cards, order status cards).
      - Show the implementation for real-time streaming of agent responses within the UI framework.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets for `orchestrator.py` and `sales_agent.py` do not contain any implementation related to voice processing (STT, TTS) or LiveKit integration.
    - There are no new files or modifications in the provided snippets that suggest the addition of a voice pipeline.
    - The `Expected Outcomes` for this task, such as 'Real-time STT → agent → TTS pipeline working end-to-end' and 'At least 2 languages demonstrated', are not addressed by the current code.
    - The task description explicitly mentions `faster-whisper STT`, `Piper TTS`, and `LiveKit Agents`, none of which are referenced or implemented in the given files.
    _Suggestions:_
      - Implement the voice pipeline by integrating `faster-whisper` for Speech-to-Text and `Piper TTS` for Text-to-Speech.
      - Utilize `LiveKit Agents` to orchestrate the real-time voice interaction, including handling mic input and speaker output.
      - Create a dedicated `voice/pipeline.py` file as suggested in the repository structure to encapsulate the voice interface logic.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (pass, 8.5/10)
    - The `sales_agent.py` file includes a dedicated `_REACT_RULES` section in its instruction prompt, outlining a clear ReAct reasoning loop for recommendations.
    - The `run_turn` function in `reasoning.py` correctly identifies reflection based on keywords in the user's message and records it as a 'Constraint revised' step.
    - The `run_turn` function also tracks tool calls and provides exit reasons for the reasoning loop, which is crucial for the 'collapsible reasoning panel' requirement.
    - The `sales_agent` is configured to use the `DEEP_MODEL`, indicating it's intended for complex reasoning tasks.
    _Suggestions:_
      - While the `_REACT_RULES` are defined, the prompt could be further refined to explicitly instruct the agent to output its 'Thought' process before 'Action' and 'Observation' to make the reasoning panel more explicit and easier to parse.
      - Consider adding a mechanism to limit the number of reflection loops or tool calls within a single turn to prevent excessive processing and costs, as the current `run_turn` only checks for `tool_call_count >= 3` for an exit reason, but doesn't enforce a hard stop.
      - Ensure the UI component for the 'collapsible reasoning panel' is implemented to visually display the steps captured by `reasoning.py`.
- **Add Observability and Evaluation (eComBot v10)** (pass, 7.5/10)
    - The learner has successfully implemented a PromptFoo evaluation suite with 11 test cases, exceeding the minimum requirement of 10.
    - The test cases cover a good range of scenarios including support flows, sales flows, RAG, hallucination guards, and security (prompt injection).
    - The PromptFoo configuration uses OpenRouter for evaluation, demonstrating awareness of cost-effective model usage.
    - The manual test files (`test_support_agent_manual.md`, `test_multiagent_manual.md`) indicate an understanding of the expected behavior for various agent interactions, which is a good foundation for automated tests.
    _Suggestions:_
      - While PromptFoo is implemented, the prompt in `promptfoo.yaml` is a static system prompt. For a true evaluation of the multi-agent system, PromptFoo should ideally be configured to interact with the actual running eComBot system (e.g., via an API endpoint or a custom provider that wraps the eComBot's input/output).
      - The task requires LangSmith tracing to be active on all agents and cost per session to be visible. There is no direct evidence in the provided files that LangSmith has been integrated or configured, nor that an admin panel for logs/evals/cost is present.
      - Add a test case for multi-turn context in PromptFoo to ensure session memory is working as expected, similar to 'Multi-turn: order query then product query' from the project requirements.

## Code Quality
- **Overall:** 8.3/10
- Readability: 8.5/10
- Modularity: 8.0/10
- Naming: 8.5/10
  - Findings:
    - In demo.py, the code is well-commented with a clear module docstring explaining usage and scenario guide, aiding readability.
    - Functions and variables use descriptive names (e.g., _pick_agent, run_scenarios, _ask) consistent with Python conventions, improving clarity.
    - The code separates concerns well: demo.py handles scenario running and interaction, session.py manages session backend selection and runner creation, and agent.py exposes the root agent, demonstrating good modularity.
    - Some helper functions in demo.py (e.g., _wrap, _sep) are small and focused, but the main scenario runner function is somewhat long and could be further decomposed.
    - The use of underscore prefix for internal functions and variables (_pick_agent, _SCENARIOS) is consistent and appropriate for Python.
    - In session.py, the get_session_service function handles backend selection cleanly, but the make_runner function mixes session creation and logging, which could be split for clarity.
    - The guardrails.py file is incomplete in the snippet, but the initial comments and pattern definitions show thoughtful design for input/output/tool guardrails.
    - Logging setup in demo.py is detailed and suppresses noise effectively, showing attention to operational concerns.
  - Suggestions:
    - In demo.py, consider breaking run_scenarios into smaller functions to improve modularity and testability.
    - Add more inline comments in complex functions like _ask to explain asynchronous event handling and error cases for maintainability.
    - In session.py, separate session creation and session retrieval logic into distinct helper functions to clarify responsibilities.
    - Ensure all files have consistent module-level docstrings and maintain the same style of comments throughout the project.
    - Complete and review guardrails.py to ensure all patterns and callbacks are fully implemented and documented for security and maintainability.

## Security
- Severity: medium
  - Issues:
    - WARN: Possible SELECT * FROM in src/tools/order_tools.py:107
    - Insecure dependency: google.adk.tools in src/tools/order_tools.py:13
  - Suggestions:
    - Replace 'SELECT *' with explicit column names in SQL queries to prevent exposing unnecessary data and to improve query performance. For example, in `get_order_status`, specify `SELECT order_id, customer_name, product_name, status, eta, carrier` instead of `SELECT *`.
    - Review and validate the `google.adk.tools` dependency. Ensure it is a legitimate and secure library, as 'adk' can sometimes be associated with advertising or potentially unwanted software. If it's a custom internal library, ensure it adheres to security best practices.
    - Ensure that `services.db` (and its `query_one`, `execute` functions) properly sanitizes and escapes all input to prevent SQL injection vulnerabilities. Although parameterized queries are used, the underlying implementation of `query_one` and `execute` must be robust.
    - Implement robust error handling and logging for database operations. While `log.error` is used, consider adding more context to the error messages, such as the specific SQL query that failed (without sensitive data) and the parameters used, to aid in debugging and incident response.
    - Consider implementing rate limiting or other abuse prevention mechanisms for the `get_order_status` and `cancel_order` functions, especially if they are exposed to external users, to prevent brute-force attacks or denial-of-service attempts.

## Summary
## Project Review Summary — eComBot

This submission shows genuine technical ambition and solid mid-to-late module work, but a critical structural issue — submitting a near-complete agent for Module 1 instead of a basic v1 implementation — significantly dragged down the overall score of 5.33/10.

**Where you shone brightest:** Your **Tools and Session Memory implementation (eComBot v2)** was outstanding at 9.5/10 — the order and product tools are well-structured, properly validated, and demonstrate excellent use of session state. Similarly, your **FastMCP server integration (eComBot v5)** earned a strong 9.5/10, with clean mock servers, solid error handling, and thoughtful delay simulation for timeout testing.

**Two areas demanding immediate attention:** First, **Module 1 compliance** — submitting a fully-featured agent with RAG, routing, and guardrails for a "basic agent" task suggests either a misread of scope or a copy-paste error; always match your submission to the module's stated boundaries. Second, the **Generative UI and Voice Interface modules (v7, v8)** scored zero — the dependencies exist in `requirements.txt`, but no implementation was submitted; incomplete modules hurt your overall score substantially.

Your code quality (8.3/10) reflects a developer who genuinely cares about clean, readable, well-named code — that foundation is something to be proud of. Tighten up the scoping discipline and complete those missing modules, and this project has the makings of an impressive portfolio piece. Keep building! 🚀