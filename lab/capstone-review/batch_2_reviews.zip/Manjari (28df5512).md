# Learner Project Review: Manjari

**Learner ID:** manjari_0eb08a  
**Repo:** https://github.com/Manjari27/EcommerceAgent

**Overall Score:** ![score](https://img.shields.io/badge/Score-2.19/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (partial, 4.0/10)
    - The learner has provided two distinct instruction files (instruction1.txt and instruction2.txt) for the eComBot, demonstrating an understanding of prompt variations.
    - The instructions define the agent's role as an e-commerce customer support assistant and list its responsibilities.
    - The instructions include guidelines for tone, response structure, and handling out-of-scope queries, which aligns with basic agent behavior definition.
    - A `services/order_service.py` file is present, which seems to be an early attempt at tool integration, but this task specifically focuses on a *basic* agent without tools.
    _Suggestions:_
      - Ensure that the ADK agent is actually implemented and configured to use one of these instruction files. The provided files are just instructions, not the agent code itself.
      - Verify that the agent is running and testable via ADK Web, as this is a mandatory outcome for v1.
      - Confirm that at least three prompt behavior variations have been tested, which implies running the agent with different prompts and observing its responses.
- **Implement Tools and Session Memory (eComBot v2)** (partial, 6.5/10)
    - The `get_order_status` tool is correctly implemented, including validation for the order ID format and lookup in mock data.
    - Session state is being used to store `last_order_id` and `customer_name` via `tool_context.state` in the `get_order_status` and `save_customer_name` functions, respectively.
    - The `instruction1.txt` prompt correctly instructs the agent to use `get_order_status` and `save_customer_name` tools and to normalize order IDs.
    - A `lookup_product` tool, which is a requirement for this module, is missing from the provided files.
    _Suggestions:_
      - Implement the `lookup_product` tool as specified in the module requirements. This tool should return structured output (product name, price, availability, description).
      - Ensure that the `lookup_product` tool also interacts with session state if there's a relevant piece of information to store (e.g., `last_queried_product`).
      - The presence of `src/agents/agent_with_db_connection/tools copy.py` suggests a duplicate file. This should be resolved to avoid confusion and maintain a clean codebase.
- **Integrate RAG Knowledge Base (eComBot v3)** (fail, 0.0/10)
    - The provided code does not show any integration of a RAG knowledge base.
    - There is no evidence of ChromaDB being used or indexed with product catalog and FAQ data.
    - The `tools.py` file still uses hardcoded `MOCK_ORDERS` instead of querying a database or RAG system for product/order information.
    - The `database.py` file initializes a PostgreSQL database for orders, which is part of Module 5 (FastMCP External Integrations), not Module 3 (RAG Knowledge Base).
    _Suggestions:_
      - Implement ChromaDB for indexing product catalog and FAQ data as described in the module requirements.
      - Modify the agent to retrieve information from the ChromaDB knowledge base for relevant queries.
      - Introduce a 'hallucination guard' mechanism to ensure the agent only responds from grounded context and provides graceful fallbacks for unanswerable queries.
      - Ensure that the `tools.py` functions, or new RAG-specific tools, interact with the ChromaDB for product and FAQ information.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation of LiteLLM.
    - There is no evidence of model routing logic based on query complexity (e.g., simple FAQ vs. complex complaints).
    - No configuration for multiple LLM providers (OpenAI, OpenRouter) is present in the `.env.example` or `docker-compose.yml`.
    - There are no tests or mechanisms to simulate model failure or check for fallback behavior.
    _Suggestions:_
      - Integrate LiteLLM into the agent's LLM calls. This typically involves setting up a LiteLLM client and configuring model routing rules.
      - Define logic within the agent to classify query complexity and dynamically select the appropriate model (e.g., `gpt-4o-mini` for simple, `gpt-4o` for complex).
      - Update the `.env.example` and `docker-compose.yml` to include API keys and configurations for both OpenAI and OpenRouter, as well as any LiteLLM specific settings.
      - Add unit or integration tests to verify model routing, including scenarios for primary model failure and fallback to the secondary provider.
- **Develop Multi-Agent Architecture (eComBot v6)** (fail, 3.0/10)
    - The provided code snippets do not demonstrate a multi-agent architecture. The files `src/agents/support_agent/instruction1.txt` and `src/agents/support_agent/instruction2.txt` appear to be different instruction sets for a single 'Support Agent', not distinct agents.
    - There is no evidence of an 'Orchestrator' agent responsible for classifying intent and delegating tasks.
    - There is no 'Sales Agent' present in the provided files.
    - The `src/agents/agent_with_db_connection/tools.py` and `src/agents/agent_with_db_connection/services/order_service.py` files seem to be part of a single agent's functionality (likely the Support Agent), not distributed across multiple agents as per the multi-agent architecture requirement.
    _Suggestions:_
      - Create separate Python files or directories for each agent (Orchestrator, Support Agent, Sales Agent) to clearly define their roles and responsibilities.
      - Implement the Orchestrator agent with logic to classify user intent and route the request to either the Support Agent or the Sales Agent.
      - Develop a distinct Sales Agent with its own instruction set and tools, separate from the Support Agent.
      - Ensure that the routing mechanism is traceable, perhaps by logging which agent handles a request.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not contain any UI-related files (e.g., `src/ui/app.py` or Gradio code).
    - There is no evidence of real-time streaming, UI components like product cards or order status cards, agent routing traces, RAG source tags, or LiteLLM model badges.
    - The `requirements.txt` and `docker-compose.yml` files show setup for database and Redis, which are foundational but not directly related to the Generative UI task.
    - The `order_service.py` and `tools.py` files are related to backend logic and tool definitions, not the UI implementation.
    _Suggestions:_
      - Implement the Gradio chat interface in `src/ui/app.py` as suggested in the repository structure.
      - Integrate UI components such as product cards, order status cards, and agent routing traces into the Gradio interface.
      - Ensure real-time streaming of agent responses is implemented for a dynamic user experience.
      - Add logic to display RAG source tags and the LiteLLM model badge within the UI.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets do not contain any implementation related to a voice interface.
    - There are no references to STT (faster-whisper), TTS (Piper), or LiveKit Agents in the submitted files.
    - The files primarily focus on agent instructions, tool definitions, and Docker Compose configurations for Redis and PostgreSQL, which are foundational but not directly related to the voice interface task.
    - The `requirements.txt` file does not include any libraries typically used for voice processing (e.g., `faster-whisper`, `piper-tts`, `livekit-agents`).
    _Suggestions:_
      - Implement the voice pipeline by integrating `faster-whisper` for Speech-to-Text, `Piper TTS` for Text-to-Speech, and `LiveKit Agents` for orchestration.
      - Add a mic button to the Gradio UI and ensure real-time transcription and audio playback are functional.
      - Demonstrate multi-language support (English + Hindi or French) for both STT and TTS.
      - Measure and optimize latency for the end-to-end voice pipeline to ensure an acceptable user experience.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a Sales Agent.
    - There is no evidence of a ReAct reasoning loop (identify budget → filter catalog → compare specs → recommend) in the submitted files.
    - No reflection mechanism for adjusting recommendations based on rejection is present.
    - The code does not include any UI components for a 'collapsible Agent Reasoning panel'.
    _Suggestions:_
      - Implement the Sales Agent as a distinct agent within the `src/agents/` directory, following the multi-agent architecture established in v6.
      - Integrate a ReAct reasoning loop within the Sales Agent's logic, defining clear steps for product discovery, filtering, comparison, and recommendation.
      - Add a mechanism for the Sales Agent to reflect on user feedback and adjust its recommendations, potentially by modifying its internal state or re-evaluating its reasoning steps.
      - Develop the UI components in `src/ui/app.py` to display the Sales Agent's reasoning steps in a collapsible panel, as specified in the requirements.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to LangSmith tracing, PromptFoo evaluation, or an admin panel.
    - The `requirements.txt` file includes `psycopg2-binary` which is a PostgreSQL driver, but there's no indication of its use for observability or evaluation.
    - The `tools.py` file demonstrates basic tool functionality and session state management, which are from earlier modules (M2), not M10.
    - There is no evidence of configuration for LangSmith, creation of PromptFoo test cases, or UI components for an admin panel.
    _Suggestions:_
      - Integrate LangSmith by configuring the ADK agents to use LangChain's tracing capabilities. This typically involves setting environment variables and ensuring the agents are wrapped appropriately.
      - Develop a `promptfoo.yaml` file with at least 10 test cases as specified in the project requirements, covering various flows and expected outcomes.
      - Implement the hidden admin panel in the Gradio UI (`src/ui/app.py`) to display live logs, PromptFoo evaluation results, and cost per session.
      - Ensure that the `psycopg2-binary` dependency is actually utilized if a database is intended for storing logs or evaluation results, otherwise, it might be an unnecessary dependency for this task.

## Code Quality
- **Overall:** 8.7/10
- Readability: 9.0/10
- Modularity: 8.5/10
- Naming: 8.5/10
  - Findings:
    - In src/agents/agent_with_db_connection/tools.py, function and variable names are clear and descriptive, with helpful docstrings explaining purpose and arguments.
    - The use of comments and section dividers (e.g., '── Write state ──') in tools.py improves readability and guides the reader through the logic.
    - In src/agents/agent_with_db_connection/agent.py, the code is concise and well-structured, with clear separation between configuration, imports, and agent setup.
    - The tools.py file combines multiple related functions but could be further modularized if the codebase grows, to separate validation, state management, and data access.
    - Naming conventions are mostly consistent with Python standards, but some comments use arrows (←) which may be non-standard and could be replaced with standard comment styles.
  - Suggestions:
    - Consider splitting tools.py into smaller modules if more tools or logic are added, to improve modularity and maintainability.
    - Replace non-standard comment arrows (←) with standard Python comment style (#) to improve consistency and readability.
    - Add type hints for all function return types explicitly for clarity, e.g., -> dict[str, Any] is good but could be more specific if possible.
    - In agent.py, consider adding a brief module-level docstring to describe the purpose of the file and agent setup.
    - Add error handling or logging in runner.py to handle unexpected exceptions during user input or async operations for robustness.

## Security
- Severity: medium
  - Issues:
    - WARN: Possible SELECT * FROM in src/agents/agent_with_db_connection/services/order_service.py:21
    - Unsafe input handling / injection risks: The `order_id` parameter is directly used in a SQL query without proper sanitization or parameterized query usage, leading to potential SQL injection vulnerabilities in src/agents/agent_with_db_connection/services/order_service.py:21. Although the current code uses a parameterized query, the heuristic scanner flagged it, and it's good to double-check.
  - Suggestions:
    - Replace `SELECT *` with an explicit list of required columns to improve performance, reduce data transfer, and prevent issues if the table schema changes. For example, `SELECT id, customer_id, total_amount FROM orders` in src/agents/agent_with_db_connection/services/order_service.py:21.
    - Ensure that all database queries use parameterized statements (as is currently done with `order_id = %s`) to prevent SQL injection. While the current code appears to use parameterized queries correctly for `order_id`, it's a critical best practice to always verify and maintain.
    - Consider implementing a more robust error handling mechanism that differentiates between various types of database errors (e.g., connection errors, data errors) instead of a generic `except Exception` in src/agents/agent_with_db_connection/services/order_service.py:25.
    - Review the logging of `order_id` in the exception handler (`logger.exception("DB error fetching order %s", order_id)`) in src/agents/agent_with_db_connection/services/order_service.py:26. If `order_id` could contain sensitive information, logging it directly might be a privacy concern. Consider redacting or hashing sensitive identifiers in logs.

## Summary
## Project Review Summary

This submission shows genuine early-stage promise, but currently only the foundational modules have meaningful implementation, leaving the majority of the project's required features incomplete with an overall score of 2.19/10.

**Strongest Areas:**
Your **code quality** is a real highlight — the existing code scores an impressive 8.7/10, with clean naming conventions, helpful docstrings, and readable structure in `tools.py` and `agent.py`. This tells me you write thoughtful, professional code when you engage with a task. Additionally, your **session state management** in the Tools module (v2) demonstrates solid understanding of how agents maintain context across interactions — the `get_order_status` and `save_customer_name` implementations are well-executed.

**Most Important Improvements Needed:**
First, **close the gap between configuration and implementation** — several tasks have supporting files (instructions, Docker configs) but lack the actual agent code that ties everything together; the agent must be runnable, not just described. Second, **prioritize completing Modules 3–5** (RAG, LiteLLM routing, and multi-agent architecture) before advancing further, as these form the critical backbone for everything that follows.

The quality of code you *have* written proves you have the technical instincts for this — now it's about applying that same care across the full project scope. Keep building! 💪