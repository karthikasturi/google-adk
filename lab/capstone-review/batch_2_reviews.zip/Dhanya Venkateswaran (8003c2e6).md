# Learner Project Review: Dhanya Venkateswaran

**Learner ID:** dhanya_venkateswaran_e456d0  
**Repo:** https://github.com/vsdhanya/GoogleADK-EComBot

**Overall Score:** ![score](https://img.shields.io/badge/Score-4.81/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 9.0/10)
    - The learner has provided multiple versions of the `support_instructions` and `stage` files, indicating an iterative development process for the agent's persona and capabilities.
    - The `stage_v1.txt` file correctly defines the initial limitations of the agent, specifically stating that it does not have access to live tools yet, aligning with the requirements for a basic agent.
    - The `support_instructions_v1.txt` and `support_instructions_v3.txt` files demonstrate an evolution in prompt design, including guidelines for tone, tool usage, and conversation patterns, which suggests testing and refinement.
    - The instructions clearly outline the agent's role as a support assistant for an electronics e-commerce store, addressing the core domain requirement.
    _Suggestions:_
      - While multiple instruction files are provided, it would be beneficial to explicitly state which instruction file (`support_instructions_v1.txt` or `stage_v1.txt`) was the final one used for eComBot v1, or if `stage_v1.txt` was the intended starting point for this module.
      - To fully meet the 'Minimum 3 prompt behavior variations tested' outcome, it would be helpful to see specific examples of how these variations were tested and their outcomes, perhaps in a separate test log or markdown file.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 9.0/10)
    - The `get_order_status` and `cancel_order` tools are implemented with both mock and database backends, demonstrating tool integration.
    - The `get_order_status` tool correctly stores `last_order_id` and `current_customer` in `tool_context.state`, indicating session state persistence.
    - The `cancel_order` tool retrieves `last_order_id` from `tool_context.state` if 'current' is passed, showing effective use of session memory.
    - The `sales_agent.py` file correctly imports and uses the `find_product` tool, and the `session.py` module provides a flexible session service factory.
    _Suggestions:_
      - Ensure that the `find_product` tool (which is imported by `sales_agent.py`) is fully implemented in `ecombot/tools.py` to match the requirements for structured output and failure scenarios.
      - Add explicit failure scenario tests for the `get_order_status` and `cancel_order` tools (e.g., invalid order ID format, order not found, already cancelled) to verify robust error handling.
      - Consider adding a mechanism to explicitly test the Redis session persistence, perhaps by simulating a session restart and checking if the state is retained.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 7.5/10)
    - The `embed_catalog.py` script successfully builds a ChromaDB index with both product and FAQ data, demonstrating the indexing of the knowledge base.
    - The `support_instructions_v3.txt` file includes a `search_knowledge_base` tool and a guideline for handling `grounded: false` results, indicating an attempt at a hallucination guard.
    - The `product_agent.py` and `sales_agent.py` still primarily rely on the `find_product` tool and do not yet integrate the `search_knowledge_base` tool for RAG, limiting their ability to answer FAQ-type questions.
    - The provided code snippets do not include the implementation of the `search_knowledge_base` tool itself, nor explicit tests for retrieval queries or hallucination detection cases.
    _Suggestions:_
      - Implement the `search_knowledge_base` tool, ensuring it queries the ChromaDB index and returns relevant documents. This tool should be integrated into the `support_agent.py`.
      - Develop specific test cases (e.g., using `pytest` or a dedicated test script) to verify that the RAG system correctly retrieves information for various product and FAQ queries, and gracefully handles unanswerable questions without hallucinating.
      - Ensure the `support_agent`'s prompt explicitly instructs it to use the `search_knowledge_base` tool for relevant queries (e.g., warranty, returns, shipping policies) and to respect the `grounded: false` flag for hallucination prevention.
- **Implement LiteLLM Model Routing (eComBot v4)** (pass, 9.0/10)
    - The `test_gateway.py` file demonstrates correct routing logic for 'fast-faq' and 'deep-support' based on query complexity.
    - The `test_routing_integration.py` confirms that `build_model` respects the `route_hint` when `LLM_GATEWAY_MODE` is 'litellm_proxy', correctly switching between 'openai/fast-faq' and 'openai/deep-support'.
    - The integration tests also verify that in 'direct' mode, the model remains fixed, ignoring routing hints, which is the expected behavior.
    - The `sales_agent.py` file correctly imports `build_model` from the gateway, indicating that the model routing mechanism is integrated into the agent's instantiation.
    _Suggestions:_
      - While the routing logic is tested, explicit tests for the fallback mechanism (e.g., simulating an OpenAI failure and verifying OpenRouter is used) would further strengthen the solution. This could involve mocking LiteLLM's internal behavior or using a test LiteLLM proxy configuration.
      - Ensure that the `build_model` function in `ecombot/gateway.py` (not provided in the snippet but implied by tests) correctly implements the LiteLLM model selection and fallback logic as described in the requirements.
- **Integrate FastMCP External APIs (eComBot v5)** (partial, 4.0/10)
    - The `tools.py` file contains mock implementations for `get_order_status` and `cancel_order`, and also includes commented-out database-backed versions. However, there is no explicit FastMCP integration visible in the provided code.
    - The `_use_database()` function and the conditional logic in `get_order_status` and `cancel_order` suggest an intention to switch between mock and database backends, but not directly to FastMCP.
    - The `_find_product_db` function is present but incomplete, indicating that the product search tool might not be fully integrated with a database backend yet, let alone FastMCP.
    - The provided `live_helpers.py` and `stage_v1.txt` do not contain any FastMCP-specific code or configurations.
    _Suggestions:_
      - Implement the FastMCP client calls within the `tools.py` file, replacing or augmenting the existing mock/database logic for order and inventory management.
      - Ensure that the FastMCP integration includes robust error handling for network issues, timeouts, and specific API error codes (e.g., 404 for invalid IDs, 500 for server errors).
      - Add specific test cases in `tests/` to simulate FastMCP API failures (timeouts, 500 errors, invalid IDs) and verify the graceful error handling.
- **Develop Multi-Agent Architecture (eComBot v6)** (partial, 6.5/10)
    - The learner has successfully created two distinct agents: `sales_agent.py` and `product_agent.py`, each with its own instruction set and tools.
    - The `sales_agent.py` is designed for recommendations and uses the `find_product` tool, aligning with the Sales Agent's role.
    - The `product_agent.py` is narrowly scoped for product discovery, also using `find_product`, which seems to overlap significantly with the Sales Agent's initial description.
    - There is no explicit Orchestrator agent provided in the relevant files that would classify intent and delegate tasks between these agents or a Support Agent.
    _Suggestions:_
      - Implement an Orchestrator agent that can classify user intent and route queries to either the `sales_agent`, `product_agent`, or a dedicated `support_agent`.
      - Consolidate the `sales_agent` and `product_agent` if their functionalities are too similar, or clearly define their distinct roles and tools to avoid redundancy.
      - Ensure that the `support_agent` (carrying M1-M5 work) is also integrated into this multi-agent architecture and can be delegated to by the Orchestrator.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets (`product_agent.py`, `sales_agent.py`, `agent.py`) do not contain any UI-related code.
    - There is no `ui/app.py` file or similar structure that would indicate the development of a Gradio chat interface.
    - The code primarily focuses on the agent logic, tool integration, and session management, which are foundational but do not directly address the UI requirements for v7.
    - The expected outcomes for this task, such as rendering distinct UI components, real-time streaming, and reflecting agent routing in the UI, are not demonstrated in the provided files.
    _Suggestions:_
      - Develop a `ui/app.py` file (as suggested in the recommended repository structure) to implement the Gradio interface.
      - Integrate the agent's responses into the Gradio UI, ensuring that structured outputs (like product cards or order status cards) are rendered appropriately.
      - Implement real-time streaming of agent responses to the Gradio interface for a better user experience.
      - Add logic to the UI to display which agent (Orchestrator, Support, Sales) is responding and to show RAG source tags and the LiteLLM model badge.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets (sales_agent.py, agent.py, product_agent.py) do not contain any implementation related to a voice interface.
    - There are no imports or references to `faster-whisper`, `Piper TTS`, or `LiveKit Agents` within the provided files.
    - The `main` functions in `sales_agent.py` and `agent.py` (for CLI execution) only handle text-based input and output.
    - The task description explicitly mentions a 'real-time voice pipeline' and 'Mic button in the Gradio UI', none of which are present or hinted at in the given code.
    _Suggestions:_
      - Implement the voice pipeline by integrating `faster-whisper` for STT and `Piper TTS` for TTS, orchestrated via `LiveKit Agents` as specified in the requirements.
      - Add a 'mic button' and associated logic to the Gradio UI (`ecombot/ui/app.py`, which was not provided but is expected for this task) to capture audio input.
      - Ensure the transcribed text from STT is fed into the Orchestrator agent, and the agent's response is then passed to TTS for audio output.
      - Consider how to handle multi-language support and measure latency for the voice pipeline.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided `ecombot/sales_agent.py` file does not show any implementation of a ReAct reasoning loop.
    - There are no explicit steps for identifying budget, filtering catalog, comparing specs, or recommending products within the agent's logic.
    - The agent's instruction (`_INSTRUCTION`) is a basic prompt for a sales assistant and does not guide it towards ReAct-style thinking or reflection.
    - There is no evidence of a mechanism for the agent to reflect on rejected recommendations or adjust its approach.
    _Suggestions:_
      - Implement a ReAct loop within the `ecombot/sales_agent.py` by defining explicit 'thought' and 'action' steps. This typically involves structuring the agent's prompt to encourage this behavior and potentially using a custom tool or internal function to manage the reasoning process.
      - Modify the agent's instruction to explicitly guide it through the ReAct steps (e.g., 'Think step-by-step: 1. Identify customer needs/budget. 2. Filter products. 3. Compare options. 4. Recommend.').
      - Introduce a mechanism for reflection. This could involve analyzing user feedback (e.g., 'I don't like that one') and using that as input for a subsequent reasoning step to adjust the recommendation.
      - Consider using ADK's `Agent.run_with_reasoning` or similar features if available, or manually structuring the prompt to output reasoning steps that can be parsed and displayed in the UI.
- **Add Observability and Evaluation (eComBot v10)** (partial, 6.0/10)
    - The `tests/live_helpers.py` and `tests/test_support_agent_live.py` files demonstrate a good foundation for testing and evaluation, including structured test cases and assertions for tool calls and replies.
    - The `ecombot/sales_agent.py` and `ecombot/agent.py` files show the use of `LlmAgent` and `Runner`, which are necessary components for LangSmith integration, but explicit LangSmith configuration or tracing setup is not visible in the provided snippets.
    - The `ecombot/session.py` file correctly handles different session backends (memory, Redis, database), which is important for state management, but doesn't directly contribute to observability or evaluation in the context of LangSmith or PromptFoo.
    - There is no explicit evidence of PromptFoo configuration (`promptfoo.yaml`) or its integration into the testing workflow within the provided code snippets. Similarly, the admin panel for live logs, eval results, and cost per session is not visible.
    _Suggestions:_
      - Integrate LangSmith by ensuring `LANGCHAIN_TRACING_V2=true` and `LANGCHAIN_API_KEY` are set in the environment, and potentially by wrapping agent calls with LangSmith contexts if not automatically handled by ADK.
      - Create a `promptfoo.yaml` file with at least 10 test cases as specified in the project requirements, covering various flows and expected outcomes.
      - Implement the hidden admin panel in the Gradio UI to display live logs, PromptFoo eval results, and cost per session, as required by the task.
      - Extend the existing live tests to include assertions related to LangSmith traces (e.g., checking for specific span names or metadata if possible) and PromptFoo results.

## Code Quality
- **Overall:** 8.7/10
- Readability: 9.0/10
- Modularity: 8.5/10
- Naming: 8.5/10
  - Findings:
    - ecombot/embed_catalog.py uses clear and descriptive function and variable names, with helpful docstrings and comments, aiding readability.
    - ecombot/sales_agent.py maintains a clear separation of concerns with agent setup, main loop, and async handling, but could benefit from more inline comments explaining key logic.
    - ecombot/tools.py is modular with separate functions for mock and database backends, but some functions are quite long and could be further decomposed for clarity.
    - Naming conventions are mostly consistent with Python standards (snake_case for functions and variables, PascalCase for classes), but some constants use mixed styles (e.g., _DATA_DIR vs _ORDER_ID_PATTERN).
    - Error handling is present but sometimes uses broad exceptions without specific handling, which could obscure root causes.
  - Suggestions:
    - Add more inline comments in sales_agent.py to explain the async event loop and response handling for maintainability.
    - In tools.py, consider splitting longer functions like get_order_status and cancel_order into smaller helper functions to improve modularity and testability.
    - Standardize constant naming conventions across modules, e.g., use all uppercase with underscores consistently for constants.
    - Replace broad except Exception clauses with more specific exception types to improve error diagnosis and robustness.
    - Add type hints to all functions in tools.py and sales_agent.py for better static analysis and developer experience.

## Security
- Severity: medium
  - Issues:
    - WARN: Possible SELECT * FROM in ecombot/tools.py:85
    - Unsafe input handling / SQL injection risk in ecombot/tools.py:85: The `query_one` function uses a parameterized query, but the `SELECT *` could expose more data than necessary if the `orders` table contains sensitive columns not intended for this function's output. While the `key` parameter is handled safely, the `*` itself is a potential information leak.
    - Unsafe input handling / SQL injection risk in ecombot/tools.py:139: The `query_one` function uses a parameterized query, but the `SELECT status, customer_name FROM orders` could expose `customer_name` which might be sensitive, depending on the application's data handling policies. While the `key` parameter is handled safely, the selection of `customer_name` should be reviewed for necessity.
    - Sensitive data in logs/output in ecombot/tools.py:160: The `message` in the cancellation success response includes `customer_name`. Depending on logging practices and how this message is exposed to users or other systems, this could lead to sensitive customer information being logged or displayed inappropriately.
  - Suggestions:
    - Replace `SELECT *` with explicit column names in `_get_order_status_db` (ecombot/tools.py:85) to adhere to the principle of least privilege and prevent accidental exposure of sensitive data. Only select the columns absolutely necessary for the function's purpose.
    - Review the necessity of returning `customer_name` in `_cancel_order_db` (ecombot/tools.py:139). If `customer_name` is not strictly required for the cancellation confirmation, remove it from the `SELECT` statement.
    - If `customer_name` is deemed necessary for the cancellation message, ensure that logging of this message is handled securely, and that the message itself is only displayed to authorized personnel or in contexts where customer name exposure is acceptable. Consider redacting or anonymizing sensitive information in logs.
    - Implement a more robust error handling strategy for database operations. Generic `except Exception` blocks can hide important details. Catch specific exceptions (e.g., `psycopg2.Error`) and log the full exception details for debugging, but return user-friendly, non-revealing error messages to the client.

## Summary
## Project Review Summary: eComBot

This submission shows genuine promise in the foundational modules but falls short in the later, more advanced stages, resulting in an overall score of 4.81/10 — a reflection of incomplete deliverables rather than poor craftsmanship.

**Where you shine:** Your early agent-building work (v1–v4) is solid and well-structured. The iterative prompt design, session memory implementation with proper `tool_context.state` usage, and LiteLLM routing logic all demonstrate thoughtful engineering. Equally impressive is your **code quality** — readability, modularity, and naming conventions score 8.7/10, which tells me you write code that others can actually maintain.

**Where you need to focus:** The two most critical gaps are the **incomplete RAG integration (v3)** — the `search_knowledge_base` tool exists in instructions but isn't implemented or wired into the agents — and the **entirely missing deliverables for v7 through v9** (Generative UI, Voice Interface, and ReAct Sales Agent), which scored zero and significantly pulled down your overall result. Additionally, the FastMCP integration (v5) needs concrete implementation beyond mock stubs.

The good news is that your backend foundations are genuinely strong — you're not rebuilding from scratch, you're building upward. Prioritize completing the RAG tool implementation and the UI layer first, as those unlock everything downstream. You've clearly got the skills; now finish the build! 💪