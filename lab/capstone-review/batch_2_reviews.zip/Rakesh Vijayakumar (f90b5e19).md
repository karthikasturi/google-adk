# Learner Project Review: Rakesh Vijayakumar

**Learner ID:** rakesh_vijayakumar_3331ba  
**Repo:** https://github.com/rakeshv95/AgenticAI

**Overall Score:** ![score](https://img.shields.io/badge/Score-3.48/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 9.0/10)
    - The learner has successfully created a basic ADK agent (`support_agent.py`) that can accept text input and respond.
    - Multiple instruction files (`support_instructions_v1.txt`, `v2.txt`, `v3.txt`) demonstrate testing different prompt behaviors, with `v3.txt` being the most comprehensive and used in the agent.
    - The agent is configured with a persona for 'eComBot, a friendly and professional customer support assistant for TechZone'.
    - The `root_agent` is correctly set to `support_agent` for ADK Web auto-discovery.
    _Suggestions:_
      - While the instructions are well-defined, explicitly testing the agent via ADK Web with specific queries for order status, product questions, and general support would fully verify the 'testable via ADK Web' requirement.
      - Ensure that the environment setup (Python 3.11+, ADK Web, OpenRouter key, LangSmith key) is documented and verified, as this is a mandatory outcome for Module 1, even if not directly visible in the provided code snippets.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 9.5/10)
    - The `order_tools.py` file correctly implements `get_order_status` and `cancel_order` tools, demonstrating tool integration.
    - Structured output is provided by the tools, returning dictionaries with relevant information like order status, items, and product details.
    - Session state persistence is implemented using `tool_context.state` to store `last_order_id` and `customer_name`, fulfilling the requirement for remembering context across turns.
    - The `get_order_status` and `cancel_order` functions include basic error handling for invalid order ID formats and orders not found, addressing failure scenarios.
    _Suggestions:_
      - While basic error handling is present, consider adding more specific failure scenario tests, such as simulating a database connection error or a tool returning an unexpected response format, to ensure robustness.
      - The `lookup_product` tool is declared in `__init__.py` and mentioned in `support_instructions_v3.txt`, but its implementation is not provided in the `order_tools.py` snippet. Ensure it's fully implemented and tested.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 8.5/10)
    - The `embed_catalog.py` script successfully loads product and FAQ data, chunks it, embeds it using LiteLLM/OpenRouter, and upserts it into a ChromaDB collection.
    - The chunking logic in `_chunk_text` attempts to break text at sentence boundaries and includes overlap, which is good for maintaining context.
    - Metadata is correctly associated with each chunk, including `source_file`, `doc_type`, `document_id`, `title`, `category`, and chunk indices, which is crucial for traceability and filtering.
    - The `support_instructions_v3.txt` and `product_agent.py` files indicate an awareness of grounding responses and avoiding hallucination by explicitly stating 'never invent specs, prices, or warranty terms' and 'Always call the appropriate tool — do NOT guess order details, prices, or stock'.
    _Suggestions:_
      - While the embedding process is robust, the actual RAG retrieval and integration into the agent's workflow (e.g., using a `retriever.py` module to fetch relevant documents before calling the LLM) is not explicitly shown in the provided files. Ensure this integration is complete.
      - The hallucination guard is mentioned in the instructions, but the implementation details (e.g., how the agent gracefully falls back or detects unanswerable queries based on RAG results) are not visible in the provided code. This should be a distinct component or logic within the agent's processing.
      - Consider adding more sophisticated chunking strategies, such as semantic chunking or using a dedicated library like LangChain's text splitters, for potentially better retrieval quality, especially for very long documents.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 0.0/10)
    - The provided files (manual test logs and a FAQ JSON) do not contain any code related to LiteLLM implementation.
    - There is no evidence of model routing logic (e.g., conditional statements to select models based on query complexity).
    - No configuration for multiple LLM providers (OpenAI, OpenRouter) is present.
    - The manual test logs do not include any scenarios or columns to test model switching, fallback, or consistency across different models/providers.
    _Suggestions:_
      - Implement LiteLLM in the agent's LLM call logic, using `litellm.completion()` and configuring multiple models/providers.
      - Add conditional logic to route queries based on complexity (e.g., keyword detection for 'FAQ' vs. 'complaint' or 'return').
      - Create specific test cases in `tests/test_support_agent_manual.md` or a new test file to verify model routing and fallback behavior, including simulating model failures.
      - Ensure that `src/config/settings.py` (or a similar configuration file) includes the necessary API keys and model definitions for LiteLLM.
- **Integrate FastMCP External APIs (eComBot v5)** (pass, 8.5/10)
    - The learner has successfully implemented two FastMCP mock servers: `inventory_server.py` and `orders_server.py`, exposing the required tools.
    - The `orders_server.py` includes `get_order_status`, `get_order_details`, and `cancel_order` tools, mirroring the requirements.
    - The `inventory_server.py` includes `check_stock` and `list_products` tools, providing product information.
    - Basic error handling for invalid IDs (e.g., `ORD-FAKE99`, `PROD-FAKE99`) is present in both servers, returning informative error messages.
    _Suggestions:_
      - While basic error handling for invalid IDs is present, the task explicitly mentions handling timeouts and 500 errors. The current implementation does not simulate these network/server-side failures. Consider adding mechanisms (e.g., a special `order_id` or `product_id` that triggers a simulated timeout or 500 error) to demonstrate graceful handling of these scenarios.
      - The `order_tools.py` file still contains `MOCK_ORDERS` and `MOCK_PRODUCTS` and references a 'Day 03 baseline / offline fallback'. For a full v5 integration, these tools should primarily interact with the FastMCP servers, with the mock data potentially serving as a true fallback if the MCP connection fails, or removed if the MCP is the primary source of truth.
      - Ensure that the agent's `order_tools.py` is updated to call the FastMCP servers instead of relying on local mock data for the primary operations, demonstrating the 'live' integration.
- **Develop Multi-Agent Architecture (eComBot v6)** (pass, 9.0/10)
    - The learner has successfully created a `sales_agent.py` file, indicating the development of a dedicated Sales Agent.
    - The `__init__.py` file shows the import and exposure of `orchestrator`, `support_agent`, and `sales_agent`, confirming a multi-agent structure.
    - The `sales_agent.py` includes a detailed instruction set for product discovery, comparisons, and recommendations, aligning with the Sales Agent's responsibilities.
    - The `sales_agent.py` is configured to use `lookup_product` tool, which is appropriate for its sales-related functions.
    _Suggestions:_
      - Ensure the `orchestrator.py` (not provided in this snippet) correctly implements the routing logic to delegate tasks between the Support and Sales agents based on user intent.
      - Verify that the `support_agent.py` (also not provided) has been updated to reflect its specialized role, potentially removing sales-related instructions or tools that are now handled by the Sales Agent.
      - Add specific test cases to the `evals/promptfoo.yaml` and `tests/test_routing.py` to explicitly validate the routing logic between the Orchestrator, Support Agent, and Sales Agent.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not contain any UI implementation using Gradio or any other framework.
    - The `requirements.txt` file indicates `chainlit>=2.0.0` for 'Day 10 — Chainlit UI', but the current task is for 'eComBot v7' which specifies Gradio.
    - There is no `src/ui/app.py` file or similar structure that would typically house UI code for this task.
    - The provided files are primarily agent definitions, instructions, and data, which are foundational but do not address the UI requirements.
    _Suggestions:_
      - Implement a Gradio-based chat interface as specified in the task requirements.
      - Ensure the UI can render at least three distinct components (e.g., product cards, order status cards, agent routing trace) based on agent output.
      - Integrate real-time streaming of agent responses into the Gradio UI.
      - Add logic to display which agent responded to a query and implement graceful fallback for unstructured output.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets (orchestrator.py, sales_agent.py, __init__.py, support_instructions_v2.txt, support_instructions_v3.txt) do not contain any implementation related to a voice interface.
    - There are no references to `faster-whisper STT`, `Piper TTS`, `LiveKit Agents`, or any audio processing libraries.
    - The Gradio UI file (`src/ui/app.py`) which would typically house the mic button and real-time transcription logic, is not included in the provided relevant files.
    - The `src/voice/pipeline.py` file, explicitly mentioned in the recommended repository structure for voice functionality, is missing.
    _Suggestions:_
      - Implement the voice pipeline in `src/voice/pipeline.py` using `faster-whisper` for STT and `Piper TTS` for TTS, integrating with LiveKit Agents.
      - Add a mic button and real-time transcription display to the Gradio UI in `src/ui/app.py`.
      - Ensure the voice input is correctly routed through the Orchestrator agent, just like text input, to leverage the existing multi-agent architecture.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (pass, 9.0/10)
    - The `sales_agent.py` file includes a detailed `_INSTRUCTION` that explicitly outlines a ReAct-style reasoning approach, covering identification of requirements, filtering, comparison, recommendation, and reflection on rejection.
    - The `reasoning.py` module correctly narrates the ReAct loop by converting `function_call` and `function_response` events into 'action' and 'observation' steps, respectively.
    - The `reasoning.py` module includes logic to detect reflection based on keywords in the user's message (`_looks_like_reflection` function) and records it as a 'reflection' step.
    - The `chainlit_app.py` integrates the `run_turn` function from `reasoning.py`, indicating that the UI is set up to display the narrated reasoning steps, fulfilling the 'collapsible reasoning panel' requirement.
    _Suggestions:_
      - While the `_looks_like_reflection` function is a good start, consider expanding the `_REFLECTION_MARKERS` with more diverse phrases or using a more sophisticated intent classification for reflection to improve robustness.
      - Ensure that the UI implementation in `chainlit_app.py` (which is partially provided) fully renders the `TurnResult.steps` in a collapsible and user-friendly manner as specified in the requirements.

## Code Quality
- **Overall:** 8.7/10
- Readability: 9.0/10
- Modularity: 8.5/10
- Naming: 8.5/10
  - Findings:
    - In demo.py, the code uses clear and descriptive function and variable names, and the scenario guides are well documented with helpful comments explaining usage and examples.
    - The main function in demo.py is well structured, but it handles multiple concerns such as agent selection, session setup, user input loop, routing, and recording history, which could be further modularized.
    - The naming conventions are mostly consistent and follow Python standards (snake_case for functions and variables, PascalCase for classes where applicable). However, some private helper functions use a leading underscore which is good, but the naming could be more descriptive in a few cases (e.g., _ask could be _get_model_reply).
    - The session.py file cleanly separates session creation logic and uses async functions appropriately, promoting modularity.
    - In src/guardrails.py, the guardrail functions are well separated by concern (input, output, tool), and the use of regex patterns is clear and well documented.
  - Suggestions:
    - Refactor the main function in demo.py to extract smaller functions for agent selection, session initialization, and the input processing loop to improve modularity and readability.
    - Rename helper functions like _ask to more descriptive names such as _get_model_reply to improve clarity.
    - Add more inline comments in complex sections, such as the async event loop in _ask, to help readers unfamiliar with async iteration.
    - In demo.py, consider moving the scenario guides to separate files or a configuration module to reduce file size and improve maintainability.
    - In guardrails.py, add type hints to all functions for better code clarity and static analysis support.

## Security
- Severity: high
  - Issues:
    - Hardcoded default credentials in docker-compose.yml for Redis (REDIS_PASSWORD: redis_secret) and PostgreSQL (POSTGRES_PASSWORD: pg_secret).
    - Potential for sensitive data in logs if `_record` function logs the full content of user input or model replies, especially if `content` contains PII or other sensitive information. (demo.py:190, demo.py:195)
  - Suggestions:
    - For `docker-compose.yml`, ensure that default passwords for Redis and PostgreSQL are strong and randomly generated in production environments. Consider using Docker secrets or a dedicated secret management system for production deployments instead of environment variables with hardcoded defaults.
    - Review the `_record` function and `src.services.history_service.record_turn` to ensure that sensitive user input or model responses are not logged or stored without appropriate sanitization, redaction, or encryption. Implement data masking or anonymization for PII.
    - Emphasize in documentation that `.env` files should never be committed to version control and that production environments should use secure secret management solutions for all credentials and API keys.

## Summary
## Project Review Summary: eComBot

This submission shows genuine promise in the foundational and intermediate modules, but three incomplete tasks significantly impact the overall score and prevent the project from functioning as a complete end-to-end application.

**Strongest Areas:**
Your agent architecture and tooling work (Tasks 1–2) are genuinely impressive — the iterative prompt engineering across three instruction versions shows real thoughtfulness, and the session state persistence with structured tool outputs demonstrates solid ADK fundamentals. The ReAct reasoning implementation (Task 9) is another standout, with a well-designed `reasoning.py` module that cleanly narrates the thought loop and integrates meaningfully with the Chainlit UI.

**Most Important Improvements Needed:**
The three incomplete tasks — LiteLLM model routing, Generative UI, and the Voice Interface — are not minor gaps; they represent core deliverables with zero implementation submitted. Prioritize these immediately, starting with the Gradio UI since it unlocks testability for other components. Additionally, the hardcoded credentials in `docker-compose.yml` are a **high-severity security issue** that must be resolved before any deployment, even for demos.

You've clearly built strong instincts for agent design — now push through the finish line on the remaining tasks. The foundation here is solid enough that completing them is entirely within your reach. Keep going!