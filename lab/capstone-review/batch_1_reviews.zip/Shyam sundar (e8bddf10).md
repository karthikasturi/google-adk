# Learner Project Review: Shyam sundar

**Learner ID:** shyam_sundar_3d0663  
**Repo:** https://github.com/cyberhades21/ADK-POC

**Overall Score:** ![score](https://img.shields.io/badge/Score-4.79/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 8.5/10)
    - The learner has provided three distinct prompt instruction files (v1, v2, v3) for the basic support agent, demonstrating an understanding of prompt engineering and behavior variation.
    - The `Google_ADK_Capstone_Final.md` document clearly outlines the project requirements and module progression, indicating a good grasp of the overall project structure and the role of eComBot v1.
    - The `Day03_LabGuide.md` file confirms the starting state of eComBot v1 as working in ADK Web, which aligns with the expected outcomes for this task.
    - The prompt variations cover different tones (warm, professional, formal) and explicitly state rules for tool usage and handling specific queries, which are crucial for a basic support agent.
    _Suggestions:_
      - While the prompt files are provided, the actual ADK agent code (e.g., `support_agent.py` or similar) that uses these instructions is not included. Including this would fully demonstrate the agent's implementation.
      - To fully verify the 'First ADK agent running and testable via ADK Web' outcome, a screenshot or a brief description of the agent's interaction in ADK Web would be beneficial.
      - For 'Minimum 3 prompt behavior variations tested', it would be helpful to see example interactions or test cases that demonstrate how each prompt variation leads to different agent behaviors.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 7.0/10)
    - The `lookup_product`, `get_order_status`, and `cancel_order` tools are implemented in `product_tools.py` and `order_tools.py` respectively, demonstrating tool calling capability.
    - The tools return structured dictionaries, fulfilling the 'Structured response format demonstrated' requirement.
    - The `support_instructions_v1.txt` and `support_instructions_v3.txt` files indicate that the agent is instructed to use these tools and handle various scenarios, including asking for an order ID if missing.
    - Error handling for invalid order IDs and uncancelable orders is present in `get_order_status` and `cancel_order`.
    _Suggestions:_
      - The current submission does not include explicit code for session state persistence using Redis. While the instructions mention it, the provided files do not show its implementation. This needs to be added to fully meet the 'Session state persists across turns (in-memory and Redis)' requirement.
      - The prompt instructions in `support_instructions_v1.txt` are quite detailed. Consider if a more concise version (like `support_instructions_v3.txt`) is sufficient for the agent to correctly use the tools, especially as the system grows.
      - Add more specific failure scenario tests for the tools, beyond just invalid IDs, such as simulating database connection errors or unexpected tool outputs, to ensure robust error handling.
- **Integrate RAG Knowledge Base (eComBot v3)** (partial, 6.5/10)
    - The `embed_catalog.py` script correctly loads product and FAQ data, embeds it using `SentenceTransformer`, and upserts it into ChromaDB, fulfilling the indexing requirement.
    - The `support_instructions_v3.txt` file has been updated, but it still primarily focuses on tool usage and does not explicitly mention grounding responses in a knowledge base or handling unanswerable queries gracefully.
    - The provided `agent.py` and `Day03_LabGuide.md` files do not show the integration of the ChromaDB retriever into the agent's workflow, nor any hallucination guard logic.
    - The `Day03_LabGuide.md` is for v2 (Tools and Session Memory), not v3 (RAG Knowledge Base), indicating a potential mismatch in the provided context for this specific task.
    _Suggestions:_
      - Integrate the ChromaDB retriever into the `LlmAgent`'s workflow. This typically involves creating a custom tool or a `before_model_callback` that performs a RAG lookup based on the user's query and injects the retrieved context into the prompt.
      - Implement a hallucination guard. This could be a post-processing step or a prompt engineering technique that instructs the agent to explicitly state when it cannot find an answer in its knowledge base.
      - Update the agent's instructions (`support_instructions_v3.txt`) to explicitly guide it on how to use the RAG knowledge base, prioritize retrieved information, and handle cases where information is not found.
- **Implement LiteLLM Model Routing (eComBot v4)** (partial, 4.0/10)
    - The learner has implemented a `llm_router.py` file with a `classify` function that uses keywords to determine message complexity, and a `call_model` function that attempts to route to a 'deep' or 'fast' model.
    - A fallback mechanism is present in `call_model` where if the 'deep' model fails, it attempts to use the 'fast' model.
    - The `agent.py` file still directly uses `LiteLlm` with `OPENROUTER_MODEL`, indicating that the LiteLLM routing logic in `llm_router.py` is not integrated into the ADK agent.
    - The configuration for models and API bases in `llm_router.py` is hardcoded to Ollama, not reflecting the requirement for OpenAI and OpenRouter providers.
    _Suggestions:_
      - Integrate the `llm_router.py`'s `call_model` function into the ADK agent's LLM configuration. This might involve creating a custom LLM class or using a callback to dynamically select the model based on the routing logic.
      - Update `llm_router.py` to configure LiteLLM with OpenAI and OpenRouter providers as specified in the requirements, rather than only Ollama. Ensure `FAST_MODEL` and `DEEP_MODEL` environment variables are correctly used for these providers.
      - Implement model failure simulation tests and response consistency checks to verify the routing and fallback mechanisms work as expected across different providers.
- **Integrate FastMCP External APIs (eComBot v5)** (pass, 8.5/10)
    - The learner successfully implemented two FastMCP mock servers: `orders_server.py` and `inventory_server.py`.
    - The `orders_server.py` exposes `order_status`, `order_cancel`, and `get_invoice` tools, correctly wrapping the underlying `order_tools.py` functions.
    - The `inventory_server.py` exposes a `check_stock` tool, which correctly uses `lookup_product` from `product_tools.py`.
    - Basic error handling for 'order not found' and 'invalid order format' is present in `order_tools.py`.
    _Suggestions:_
      - Implement more robust error handling within the FastMCP tools themselves (e.g., `order_status`, `check_stock`) to simulate network issues, timeouts, or 500 errors as required by the prompt, rather than just data validation errors.
      - Add a `get_invoice` function to `order_tools.py` to keep the tool logic separate from the MCP server definition, similar to `get_order_status` and `cancel_order`.
      - Consider adding a `get_product_details` tool to `product_tools.py` that returns more comprehensive product information, which `check_stock` could then leverage, aligning with the `lookup_product` function's capabilities.
- **Develop Multi-Agent Architecture (eComBot v6)** (fail, 3.0/10)
    - The learner has created a `support_agent.py` file, indicating an intention to define a Support Agent.
    - The `support_agent.py` correctly loads instructions from a text file and initializes an `LlmAgent` with a LiteLLM model.
    - However, the submission only includes the definition for a single `eComBot_Support` agent. The core requirement of splitting into an Orchestrator, Support Agent, and Sales Agent is not met.
    - There is no evidence of a multi-agent architecture, task delegation, or routing logic between different agents.
    _Suggestions:_
      - Create separate Python files for the Orchestrator and Sales Agent, similar to how `support_agent.py` is structured.
      - Implement the Orchestrator agent with logic to classify user intent and delegate tasks to either the Support Agent or the Sales Agent based on the intent.
      - Define the Sales Agent with its specific instructions and responsibilities for product discovery, recommendations, and comparisons.
      - Ensure that the overall system can demonstrate routing, for example, by having a main entry point that uses the Orchestrator to direct queries.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided `Day03_LabGuide.md` and `ui/rag.html` files do not demonstrate the implementation of a Gradio chat interface.
    - The `Day03_LabGuide.md` focuses on tool calling and in-memory session state, which are aspects of eComBot v2, not v7.
    - The `ui/rag.html` file appears to be a static HTML template for a RAG Explorer, not a dynamic Gradio chat interface with generative UI components.
    - There is no evidence of real-time streaming, agent routing display, or specific generative UI components like product cards or order status cards.
    _Suggestions:_
      - Implement a Gradio application (`app.py` in `src/ui/`) that integrates with the eComBot agents.
      - Design and implement custom Gradio components or use existing ones to render product cards, order status cards, and other rich UI elements based on agent output.
      - Ensure the Gradio interface can display which agent responded (Orchestrator, Support, Sales) and stream responses in real-time.
      - Integrate the RAG source tags and LiteLLM model badge into the Gradio UI as specified in the requirements.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets do not contain any implementation related to a voice interface (STT, TTS, LiveKit, mic button).
    - The `Day01_Day02_LabGuide_Final.md` and `Day12_LabGuide.md` files describe the requirements for the voice interface but do not show any learner's code for it.
    - The `src/agents/support_instructions_v2.txt` file is a text instruction for an agent and is not relevant to the voice interface implementation.
    - The provided files focus on agent setup, prompt refinement, ReAct reasoning, observability, and guardrails, which are tasks from other modules (v1, v9, v10, v11).
    _Suggestions:_
      - Implement the real-time STT (faster-whisper), TTS (Piper), and LiveKit orchestration as described in the project requirements for Module 8.
      - Integrate a mic button into the Gradio UI to activate voice input and display live transcription.
      - Ensure the multi-agent routing works identically for both text and voice inputs.
      - Demonstrate multi-language support (English + Hindi or French) for the voice interface.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided `Day01_Day02_LabGuide_Final.md` and `CAPSTONE_GUIDE.md` documents describe the initial setup and features up to Day 5 (RAG Knowledge Base).
    - There is no code or documentation provided that specifically addresses the implementation of a ReAct reasoning loop within a Sales Agent.
    - The concept of reflection on rejection, a collapsible reasoning panel in the UI, or validation of decision correctness and loop termination are not mentioned or demonstrated in the provided files.
    - The provided files focus on the foundational aspects of the `eComBot_Support` agent, session memory, SQLite, and RAG, which are prerequisites for later modules but do not fulfill the requirements of v9.
    _Suggestions:_
      - Implement a dedicated `SalesAgent` with a ReAct reasoning loop that includes steps like identifying budget, filtering catalog, comparing specs, and recommending products.
      - Ensure the Sales Agent can reflect and adjust its recommendations if the initial suggestions are rejected by the user.
      - Develop a UI component (e.g., in Gradio) to display the Sales Agent's thought process in a collapsible 'Agent Reasoning' panel.
      - Add test cases to validate the correctness of the Sales Agent's decisions and the proper termination of its ReAct loop.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - The provided `Day10-LabGuide.md` and `src/agents/support_agent.py` files do not contain any implementation related to LangSmith tracing, PromptFoo evaluation, or an admin panel.
    - The `Day10-LabGuide.md` focuses on building a Chainlit UI (eComBot v7), which is a prerequisite for v10 but not the core task itself.
    - The `src/agents/support_agent.py` only defines a basic `LlmAgent` with an instruction file and LiteLLM model, without any observability configurations.
    - There are no references to `LangSmith`, `PromptFoo`, or any related configurations in the provided code snippets.
    _Suggestions:_
      - Implement LangSmith tracing by configuring the `LANGCHAIN_TRACING_V2` and `LANGCHAIN_API_KEY` environment variables and ensuring ADK agents are instrumented for tracing.
      - Create a `promptfoo.yaml` file in the `evals/` directory with at least 10 test cases covering the specified scenarios (order lookup, cancellation, product discovery, RAG, error handling, guardrails, etc.).
      - Develop a hidden admin panel within the Gradio/Chainlit UI to display live logs, evaluation results, and cost per session, as outlined in the requirements.
      - Ensure that the ADK agents are configured to report model usage and other relevant metrics that can be captured by LangSmith for cost tracking.

## Code Quality
- **Overall:** 8.3/10
- Readability: 8.5/10
- Modularity: 8.0/10
- Naming: 8.5/10
  - Findings:
    - In src/agent.py, the function extract_and_inject_session is well-commented and uses clear variable names, aiding readability.
    - In ui/server.py, the handle function is quite large and handles multiple concerns (static files, proxying, API routing), which reduces modularity.
    - Naming conventions are consistent across files, using snake_case for functions and variables, and PascalCase for classes, following Python conventions.
    - In ui/server.py, some imports are grouped together (e.g., sys, json, sqlite3) but could be better organized for clarity.
    - In scripts/init_db.py, the database initialization script is straightforward and uses clear naming for tables and columns.
  - Suggestions:
    - Refactor ui/server.py to split the large handle function into smaller route-specific handlers to improve modularity and readability.
    - Add more docstrings to functions in ui/server.py and scripts/init_db.py to explain their purpose and usage.
    - Organize imports in ui/server.py into standard library, third-party, and local imports with blank lines separating them for better readability.
    - In src/agent.py, consider breaking down extract_and_inject_session into smaller helper functions for extracting order ID and customer name to improve modularity.
    - Add error handling or logging in critical sections, such as file reading in src/agent.py and database operations in ui/server.py, to improve robustness.

## Security
- Severity: low
  - Issues:
    - Possible SELECT * FROM in CAPSTONE_GUIDE.md:154
    - Possible SELECT * FROM in CAPSTONE_GUIDE.md:158
    - Possible SELECT * FROM in Day04_LabGuide.md:119
    - Possible SELECT * FROM in Day04_LabGuide.md:130
    - Possible SELECT * FROM in Day04_LabGuide.md:158
    - Possible SELECT * FROM in src/tools/order_tools.py:11
    - Possible SELECT * FROM in src/tools/order_tools.py:23
    - Possible SELECT * FROM in src/tools/product_tools.py:8 (not provided in code sample, but flagged by scanner)
    - Exposed credentials/API keys: The `DB_PATH` is read from an environment variable (`.env`), which is good practice. However, the `.env.example` file is mentioned, implying that sensitive configuration might be committed to version control if not handled carefully. (Day04_LabGuide.md:79)
    - Unsafe input handling/injection risks: The `order_id` is sanitized using `.strip().upper()` and then used in a parameterized query, which prevents direct SQL injection. This is good. (src/tools/order_tools.py:11, src/tools/order_tools.py:23)
  - Suggestions:
    - Replace `SELECT *` with explicit column names in all SQL queries. This improves performance, reduces memory usage, and makes the code more robust to schema changes. For example, in `get_order_status`, if only `status` and `can_cancel` are needed, select only those columns.
    - Ensure that `.env` files containing sensitive information (like `DB_PATH` if it were a remote database connection string with credentials) are properly excluded from version control using `.gitignore`.
    - While parameterized queries are used for `order_id`, ensure all other user-controlled inputs that might be used in SQL queries are also handled with parameterized queries or proper escaping.
    - Review the `product_tools.py` file (which was flagged by the scanner but not provided) to ensure `SELECT *` is replaced with explicit column names and input handling is secure.

## Summary
## Project Review Summary

This submission shows genuine promise in the foundational modules but falls significantly short in the more advanced stages, resulting in an overall score of 4.79/10 — an honest reflection of a project that is roughly half-complete.

**Where you shine:** Your strongest work is in the **FastMCP External APIs integration (v5, 8.5/10)** and the **Basic Support Agent (v1, 8.5/10)**. The MCP server implementations are clean and well-structured, and your three prompt variation files demonstrate a solid, practical understanding of prompt engineering. Your code quality is also commendable — consistent naming conventions, good readability, and parameterized SQL queries showing security awareness are all marks of a developer building good habits early.

**Where you must focus next:** The two most critical gaps are the **incomplete multi-agent architecture (v6, 3.0/10)** and the **missing advanced modules (v7–v10, all scoring 0.0)**. The multi-agent system — the architectural backbone of the later project — needs an Orchestrator and Sales Agent built alongside the Support Agent, with real routing logic connecting them. Without this foundation, the Generative UI, Voice Interface, ReAct reasoning, and Observability layers have nothing to build upon. Additionally, the **LiteLLM routing (v4)** needs to be wired into the actual ADK agent rather than existing as a standalone, unintegrated module.

You've clearly grasped the core concepts — now it's time to connect the pieces. Push through the remaining modules and you'll have a genuinely impressive end-to-end system. Keep going! 💪