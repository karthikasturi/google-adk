# Learner Project Review: Aathi Vignesh

**Learner ID:** aathi_vignesh_f4fb27  
**Repo:** https://github.com/aathi24/ecom-bot

**Overall Score:** ![score](https://img.shields.io/badge/Score-2.46/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (partial, 6.0/10)
    - The `support_instructions_v1.txt` file clearly defines the agent's persona, goals, rules, and tone, which is a good start for prompt engineering.
    - The instructions include specific rules to prevent hallucination regarding order status, inventory, ETA, and pricing, aligning with the project's problem-solving goals.
    - The agent is instructed to stay within the electronics e-commerce domain and politely redirect unrelated questions, demonstrating an understanding of scope.
    - The provided code snippet only shows the instructions, not the actual agent implementation or how it's integrated with ADK Web.
    _Suggestions:_
      - Provide the Python code for the ADK agent itself, demonstrating how these instructions are loaded and used.
      - Show evidence of the agent running and being testable via ADK Web, perhaps with a screenshot or a brief description of test interactions.
      - Include examples of at least three prompt behavior variations tested, as required by the 'Mandatory outcomes'.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 7.5/10)
    - The `get_order_status` tool is implemented and correctly uses `ToolContext` to persist `customer_name` and `last_order_id` in session state.
    - The tool handles various scenarios including missing order ID, invalid order ID format, and order not found, returning appropriate error messages.
    - The `support_instructions_day3.txt` clearly outlines the agent's policy for using the `get_order_status` tool and managing session state for customer names.
    - The `tool` decorator is correctly defined as a no-op, allowing the `get_order_status` function to be used as a tool.
    _Suggestions:_
      - While `get_order_status` is implemented, the task also mentions `lookup_product`. Ensure a `lookup_product` tool is also implemented and integrated.
      - The task requires session state to persist via Redis. The current implementation uses `tool_context.state`, which typically implies in-memory or a framework-managed state. Verify that the underlying ADK setup or a separate Redis integration ensures persistence across sessions.
      - Add more comprehensive unit tests for `get_order_status` to cover all failure scenarios and successful state persistence, as the task explicitly requires 'Minimum 3 failure scenario tests passing'.
- **Integrate RAG Knowledge Base (eComBot v3)** (fail, 2.0/10)
    - The provided code snippets do not show any implementation of ChromaDB, sentence-transformers, or any RAG-related components.
    - The `support_instructions_v3.txt` files across `day1`, `day2`, and `day3` are identical and primarily focus on agent mission, scope, operating rules, and style guide, without mentioning RAG.
    - The `product_agent.py` file defines a basic `LlmAgent` but does not include any RAG integration for product discovery or comparison.
    - The `agent.py` file for `day3` only builds a `support_agent` with tool calling enabled, but no RAG.
    _Suggestions:_
      - Implement ChromaDB initialization and indexing of product catalog and FAQ data. This typically involves loading data, creating embeddings, and adding them to a ChromaDB collection.
      - Modify the agent's logic (e.g., in `support_agent.py` or `product_agent.py`) to perform a retrieval step from ChromaDB before generating a response.
      - Add a mechanism to detect when a query cannot be answered from the retrieved context and implement a graceful fallback message to prevent hallucination.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation of LiteLLM model routing.
    - There is no evidence of configuring multiple LLM providers (e.g., OpenAI and OpenRouter) or logic for model switching based on query complexity.
    - The `sales_agent.py` file uses `LiteLlm(model=settings.model)` but `settings.model` is a single model string, not a LiteLLM configuration for routing or fallback.
    - The test files provided are for manual testing of agent behavior and prompt variants, not for validating LiteLLM routing or fallback mechanisms.
    _Suggestions:_
      - Implement LiteLLM's advanced configuration to define multiple models and routing rules (e.g., `model_map` or `router_mode`).
      - Introduce logic within the agent or a wrapper function to dynamically select models based on the complexity of the user's query (e.g., using keyword detection or a separate classification LLM).
      - Add specific LiteLLM configuration for fallback to OpenRouter if the primary model fails, and write unit tests to simulate and verify this behavior.
      - Create automated tests to verify that simple FAQ queries are routed to `gpt-4o-mini` and complex queries to `gpt-4o`, and that fallback works as expected.
- **Integrate FastMCP External APIs (eComBot v5)** (fail, 2.0/10)
    - The provided code snippets for `order_tools.py` across `day1`, `day2`, and `day3` are identical and only contain mock data and logic for `get_order_status`.
    - There is no evidence of integration with actual FastMCP mock servers for order management or inventory.
    - The tools `cancel_order`, `get_invoice`, and `check_stock` are not implemented or referenced in the provided code.
    - Error handling is present for invalid order ID format and order not found, but not for API-specific failures like timeouts or 500 errors, which would be handled by FastMCP integration.
    _Suggestions:_
      - Implement the FastMCP mock servers as described in the project requirements for order management and inventory.
      - Update `order_tools.py` to make actual calls to the FastMCP order management server for `get_order_status`, `cancel_order`, and `get_invoice`.
      - Create a new tool (e.g., `product_tools.py`) that integrates with the FastMCP inventory server for `check_stock`.
      - Ensure that the FastMCP integration includes mechanisms to gracefully handle API failures such as timeouts, 404s, and 500 errors, as specified in the requirements.
- **Develop Multi-Agent Architecture (eComBot v6)** (fail, 0.0/10)
    - The provided files only contain various versions of `support_instructions.txt`.
    - There is no evidence of an Orchestrator agent, a Support Agent, or a Sales Agent being implemented.
    - No code demonstrating the splitting of a single agent into multiple specialized agents is present.
    - There is no indication of a Planner–Executor pattern or task delegation logic.
    _Suggestions:_
      - Implement the Orchestrator agent responsible for classifying user intent and delegating tasks.
      - Create distinct `Support Agent` and `Sales Agent` modules, each with their specific instructions and tool access.
      - Develop the logic for the Orchestrator to route queries like 'Where is my order?' to the Support Agent and 'What phone should I buy?' to the Sales Agent.
      - Ensure that the previous work (M1-M5) is integrated into the Support Agent as specified.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a Gradio chat interface or generative UI components.
    - The files `product_agent.py`, `agent.py`, `requirements.txt`, `support_instructions_v3.txt`, and `support_instructions_day3.txt` are related to agent definition, instructions, and dependencies, but not UI.
    - There is no evidence of real-time streaming, UI components like product/order cards, agent routing traces, RAG source tags, or model badges.
    - The task specifically requires a UI implementation, which is entirely missing from the provided context.
    _Suggestions:_
      - Implement a `ui/app.py` file as suggested in the repository structure, using Gradio to build the chat interface.
      - Integrate UI components such as product cards, order status cards, agent routing traces, RAG source tags, and LiteLLM model badges into the Gradio interface.
      - Ensure real-time streaming of agent responses is implemented in the UI.
      - Add graceful fallback mechanisms for unstructured agent output within the UI.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a voice interface.
    - There are no references to `faster-whisper`, `Piper TTS`, `LiveKit Agents`, or any voice-related libraries or functionalities.
    - The files provided are primarily focused on agent definitions and instructions, which are foundational but do not address the specific requirements of a voice interface.
    _Suggestions:_
      - Implement the `faster-whisper` library for Speech-to-Text (STT) to transcribe audio input from the microphone.
      - Integrate `Piper TTS` for Text-to-Speech (TTS) to convert agent responses into audio output.
      - Utilize `LiveKit Agents` to orchestrate the real-time voice pipeline, handling audio streaming and interaction.
      - Add a 'voice' directory under `src/` as suggested in the repository structure, and implement the voice pipeline logic there.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided `sales_agent.py` files across `day1`, `day2`, and `day3` directories are identical and represent a basic `LlmAgent` initialization.
    - There is no evidence of a ReAct reasoning loop implementation within the `sales_agent.py` code.
    - The code does not demonstrate any reflection mechanism for adjusting recommendations based on rejection.
    - No UI-related code (like a collapsible reasoning panel) was provided or referenced, which is a key expected outcome for this task.
    _Suggestions:_
      - To implement ReAct, consider using ADK's `ToolAgent` or a custom agent that explicitly defines a thought-action-observation loop. This typically involves defining specific tools for filtering, comparing, and recommending products.
      - For reflection, you might need to capture user feedback (e.g., 'I don't like that recommendation') and then modify the agent's internal state or prompt to guide it towards a different approach.
      - Integrate with the UI layer (Gradio, as per requirements) to display the agent's thought process in a collapsible panel. This would involve structuring the agent's output to include its reasoning steps.
      - Review the ADK documentation or examples for implementing ReAct patterns, as this often involves more than just an `LlmAgent` with an instruction.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - No evidence of LangSmith integration or configuration in the provided files.
    - No PromptFoo evaluation suite (e.g., `promptfoo.yaml` or related test files) was found.
    - There is no implementation for an admin panel or any UI components related to observability (logs, eval results, cost per session).
    - The provided files are primarily manual test cases and a basic agent definition, which do not address the requirements for observability and evaluation.
    _Suggestions:_
      - Integrate LangSmith by configuring the ADK agents to use LangSmith for tracing. This typically involves setting up environment variables and potentially wrapping agent calls.
      - Create a `promptfoo.yaml` file with at least 10 test cases covering the specified scenarios (order lookup, cancellation, product discovery, RAG, guardrails, etc.).
      - Develop the UI components for an admin panel within the Gradio interface to display live logs, PromptFoo evaluation results, and session costs.
      - Ensure that cost per session is being tracked and reported, likely through LiteLLM's integration with LangSmith or direct logging.

## Code Quality
- **Overall:** 8.7/10
- Readability: 8.5/10
- Modularity: 9.0/10
- Naming: 8.5/10
  - Findings:
    - In lab/day2/run_variant.py, the main function is well-structured with clear variable names and helpful docstring, but lacks inline comments explaining key steps like session creation and event handling.
    - In lab/day3/run.py, helper functions _build_message and ask improve modularity and readability by encapsulating repeated logic.
    - The naming conventions are mostly consistent and follow Python standards, e.g., snake_case for functions and variables, PascalCase for classes (imported).
    - Some files like lab/day1/agent.py and lab/day2/agent.py are minimal but clear, serving as entrypoints with straightforward naming.
    - The use of magic strings for user and session IDs (e.g., 'user-' prefix) is consistent but could be abstracted for reuse.
  - Suggestions:
    - Add brief inline comments in run_variant.py and run.py to explain non-obvious logic, such as session creation and event loop processing.
    - Extract repeated user_id and session_id generation logic into a utility function to avoid duplication across run.py files.
    - Consider adding error handling for command-line arguments to provide user feedback if inputs are missing or malformed.
    - Use constants or configuration for user/session ID prefixes instead of hardcoded strings to improve maintainability.
    - Add type hints to helper functions like _build_message and ask in day3/run.py for better clarity and static analysis.

## Security
- Severity: medium
  - Issues:
    - Exposed API key in environment variable check: lab/day2/run_variant.py:22
    - Exposed API key in environment variable check: lab/day1/run.py:21
  - Suggestions:
    - Ensure that API keys and other sensitive credentials are not directly exposed in code or committed to version control. Use secure environment variable management or a secrets management service.
    - Review the `.gitignore` file to ensure all sensitive files and directories are properly excluded from version control. While `.env` files are listed, ensure no other sensitive files are accidentally included.
    - For production environments, consider more robust session management than `InMemorySessionService`, which is not scalable or persistent across application restarts. Options include database-backed sessions or dedicated session stores like Redis.
    - Sanitize and validate all user inputs (`sys.argv`) to prevent potential injection attacks or unexpected behavior, especially when these inputs are used to construct queries or interact with other systems. Although the current usage seems limited to display and agent input, it's a good practice to implement input validation early.

## Summary
## Project Review Summary: eComBot

This submission shows early-stage foundational work, but with an overall score of 2.46/10, the majority of the project's core requirements remain unimplemented and need significant attention before this can be considered a functional eCommerce agent system.

**Where you're doing well:**

Your **prompt engineering and instruction design** (Tasks 1–2) demonstrate genuine thoughtfulness — the agent personas are clearly scoped, hallucination guardrails are explicitly defined, and session state handling in `get_order_status` shows you understand how tools and context interact. Additionally, your **code quality is genuinely strong** (8.7/10) — the modular helper functions, consistent naming conventions, and clean entry-point structure reflect good engineering habits that will serve you well as the project grows.

**Where you must focus next:**

The most critical gap is **feature completion** — Tasks 3 through 10 (RAG, LiteLLM routing, FastMCP, multi-agent architecture, UI, voice, ReAct, and observability) are either entirely missing or only minimally stubbed. These aren't optional extensions; they are the core of the project. Alongside this, address the **medium-severity security findings** around API key exposure in your run scripts before any further development.

You've clearly built a solid foundation in prompt design and code structure — now it's time to build upward. Take it one milestone at a time, and don't hesitate to revisit the lab materials for Tasks 3 and 6 first. You've got this! 💪