# Learner Project Review: Chiristo Selva Nimal

**Learner ID:** chiristo_selva_nimal_27fca0  
**Repo:** https://github.com/nimalchrist/google-adk-course-capstone-project

**Overall Score:** ![score](https://img.shields.io/badge/Score-5.02/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 7.5/10)
    - The learner has created two distinct instruction sets for the support agent, `support_instructions_v1.txt` and `support_instructions_v3.txt`, demonstrating an understanding of prompt design.
    - The instructions clearly define the agent's role, boundaries, and tone, which are crucial for a basic support agent.
    - The `support_instructions_v3.txt` file includes a 'Response format' section, indicating an attempt to guide structured output, which aligns with the project's goal of precise responses.
    - The presence of multiple instruction files suggests the learner is experimenting with prompt variations, which is a mandatory outcome for this module.
    _Suggestions:_
      - To fully meet the 'Minimum 3 prompt behavior variations tested' requirement, ensure that a third distinct prompt variation is created and tested, or clearly document how these two prompts represent different behaviors.
      - While the instructions are good, the submission does not include the actual ADK agent code or evidence of it running and being testable via ADK Web. This is a critical component of the 'First ADK agent running' outcome.
      - Provide evidence of environment setup verification (Python 3.11+, ADK Web, OpenRouter key, LangSmith key) as per the mandatory outcomes.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 8.5/10)
    - The `lookup_product` tool is correctly implemented, allowing partial name matching and returning structured product details.
    - The `check_stock` tool is implemented and can retrieve stock information for a given product ID, including using a 'current' product ID from session state.
    - Session state (`tool_context.state`) is effectively used to store `current_product_id`, `last_lookup_key`, and `last_intent` across turns for both tools.
    - Both tools include basic error handling for cases like empty product names or product not found, returning informative messages.
    _Suggestions:_
      - While the `_try_db_query_all` and `_try_db_query_one` functions are present, they currently log a debug message and return `None` if the DB is unavailable, falling back to mock data. For a more robust solution, consider implementing a clear strategy for when the DB is truly unavailable vs. when mock data should be used, perhaps through a configuration flag or a more explicit fallback mechanism.
      - The `lookup_product` tool currently stores only the first matching product's ID in `current_product_id`. If multiple products match a partial search, the agent might need to clarify which product the user is interested in before setting the `current_product_id` for subsequent actions like `check_stock`.
      - Add specific failure scenario tests for the tools, such as passing an invalid product ID to `check_stock` or a non-existent product name to `lookup_product`, to ensure the error handling is robust and the agent responds appropriately.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 9.0/10)
    - The `embed_catalog.py` script successfully loads product and FAQ data from JSON files, demonstrating correct data ingestion.
    - ChromaDB is correctly initialized and populated with embeddings using `litellm.embedding`, indicating a functional RAG setup.
    - The `support_instructions_v3.txt` file includes clear directives for the agent to avoid hallucination and cite sources, which is crucial for the 'hallucination guard' requirement.
    - The `build_collection` function handles existing collections by attempting to delete them before recreation, ensuring a clean rebuild process.
    _Suggestions:_
      - While the instructions mention hallucination guard, the provided code snippets don't explicitly show how the agent *uses* the RAG results or how it *detects* and *handles* unanswerable queries beyond the prompt instructions. This would typically involve a retrieval step within the agent's logic and a confidence threshold or similar mechanism. Consider adding a dedicated `retriever.py` module (as suggested in the repo structure) and integrating its output directly into the agent's prompt or decision-making process.
      - The `embed` function uses `openrouter/openai/text-embedding-3-small`. Ensure that the `OPENROUTER_API_KEY` is correctly configured and available in the environment for the embedding process to work reliably in a production setting.
      - The `build_collection` function uses `chromadb.EphemeralClient()`. For persistence and scalability in a production environment, consider switching to a persistent client (e.g., `chromadb.PersistentClient`) or a managed ChromaDB instance.
- **Implement LiteLLM Model Routing (eComBot v4)** (pass, 8.5/10)
    - The `router.py` file correctly implements LiteLLM Router for model routing and fallback, using `_make_router` to configure primary and backup models.
    - Two distinct routers, `faq_router` and `support_router`, are created, demonstrating routing based on query complexity (fast vs. deep models).
    - Fallback mechanisms are implemented with `fallbacks` and `num_retries` in the `_make_router` function, and demonstrated with `fallback_demo_router` and `timeout_demo_router`.
    - Callbacks for success and failure are correctly set up to log routing events, which is crucial for observability.
    _Suggestions:_
      - While `classify_query` provides basic routing logic, consider integrating it directly with the agent's decision-making process to dynamically select the appropriate router based on the classified intent.
      - The `test_support_agent_manual.md` file is a good start for manual testing, but for 'Model failure simulation test passing' and 'Response consistency checks across providers', automated unit tests would be more robust and repeatable.
      - Ensure that the `OPENROUTER_API_KEY` is consistently used across all LiteLLM configurations and that the `api_base` and `HTTP-Referer` headers are correctly set for OpenRouter calls, as seen in `stt_openrouter.py` and `tts_openrouter.py`.
- **Integrate FastMCP External APIs (eComBot v5)** (pass, 9.5/10)
    - Two FastMCP mock servers (`inventory_server.py` and `orders_server.py`) have been successfully implemented, exposing `check_stock`, `list_variants`, `get_order_status`, `get_order_details`, and `cancel_order` tools.
    - Error handling for invalid IDs is present in both servers, returning structured messages indicating that the product/order was not found.
    - The `cancel_order` tool includes logic for handling already cancelled or delivered orders, and requires explicit confirmation, demonstrating robust error and state management.
    - API failure simulation for timeouts is implemented in `inventory_server.py` using an environment variable `INVENTORY_SEARCH_DELAY_SECONDS`.
    _Suggestions:_
      - While timeout simulation is present for the inventory server, consider adding similar delay/timeout simulation capabilities to the `orders_server.py` to fully cover API failure simulation for all tools.
      - The `get_invoice` tool was mentioned in the requirements but not found in the provided `orders_server.py`. Ensure all required tools are implemented.
      - Consider adding a mechanism to simulate 500 errors (internal server errors) for both MCP servers to test more comprehensive failure scenarios.
- **Develop Multi-Agent Architecture (eComBot v6)** (partial, 4.0/10)
    - The learner has provided multiple instruction files for a 'Support Agent' (v1, v2, v3), indicating an understanding of agent roles and iterative refinement.
    - The presence of different versions of support instructions suggests an attempt to define the persona and boundaries for a specialized agent.
    - However, there is no evidence in the provided files of an 'Orchestrator' agent or a 'Sales Agent', which are crucial components of the multi-agent architecture for this module.
    - The core requirement of task delegation and routing between different agents cannot be assessed with the current submission.
    _Suggestions:_
      - Implement the Orchestrator agent responsible for classifying intent and delegating tasks to the appropriate specialized agents (Support or Sales).
      - Create the Sales Agent with its own distinct instructions and capabilities, focusing on product discovery, recommendations, and comparisons.
      - Demonstrate the routing logic, perhaps through a main application file or a test, showing how a query like 'Where is my order?' goes to the Support Agent and 'What phone should I buy?' goes to the Sales Agent.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not include any UI implementation (e.g., Gradio application).
    - There is no evidence of distinct UI components being rendered from agent output.
    - Real-time streaming, agent routing reflection in the UI, or graceful fallback for unstructured output cannot be assessed without a UI.
    - The `requirements.txt` file includes `chainlit>=2.0.0`, which is a UI framework, but no corresponding implementation is present in the provided files.
    _Suggestions:_
      - Implement the Gradio chat interface as described in the task requirements.
      - Ensure the agent's output is structured to allow for rendering of product cards, order status cards, RAG source tags, and model badges.
      - Integrate real-time streaming capabilities into the Gradio UI for agent responses.
      - Demonstrate how the UI reflects agent routing and handles various output types, including graceful fallback for unstructured content.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets for `orchestrator.py`, `support_instructions_v2.txt`, and `sales_agent.py` do not contain any implementation related to a voice interface.
    - There are no imports or references to `faster-whisper`, `Piper TTS`, `LiveKit Agents`, or any other voice-related libraries or services.
    - The Gradio UI (`ui/app.py`) and voice pipeline (`voice/pipeline.py`) files, which would be central to this task, are not included in the provided relevant files.
    - The task description explicitly mentions a 'real-time voice pipeline' and 'Mic button in the Gradio UI', none of which are present in the given code.
    _Suggestions:_
      - Implement the voice pipeline using `faster-whisper` for STT and `Piper TTS` for TTS, orchestrated via `LiveKit Agents` as specified in the requirements.
      - Integrate a microphone button and live transcription display into the Gradio UI (`ui/app.py`).
      - Ensure the voice input is routed through the Orchestrator agent, similar to how text input is handled, and that the agent's response is then converted to speech.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 3.0/10)
    - The `sales_agent.py` file shows no evidence of a ReAct reasoning loop implementation. The instruction is a static string, and there are no explicit steps for identifying budget, filtering, comparing, or recommending.
    - There is no mechanism for the Sales Agent to reflect on a rejected recommendation and adjust its approach.
    - The `chainlit_app.py` file does not include any code to render a collapsible 'Agent Reasoning' panel in the UI, which is a key requirement for this module.
    - The current implementation of the Sales Agent is a basic tool-using agent, similar to what would be expected in earlier modules, not an upgraded ReAct agent.
    _Suggestions:_
      - Modify the `_build_sales_instruction` function or the agent's prompt to incorporate ReAct principles, guiding the agent through explicit thought steps (e.g., 'Thought:', 'Action:', 'Observation:').
      - Implement a mechanism within the Sales Agent to handle user feedback (e.g., 'I don't like that recommendation') and trigger a reflection process to generate an alternative recommendation.
      - Update `chainlit_app.py` to parse the agent's output for specific markers (e.g., 'Thought:') and render them within a collapsible UI component, as specified in the requirements.
      - Consider using a structured output format for the Sales Agent's reasoning steps to make it easier to parse and display in the UI.
- **Add Observability and Evaluation (eComBot v10)** (partial, 4.0/10)
    - The `test_support_agent_manual.md` file provides a good starting point for defining test cases, covering various scenarios for tool calling, session state, and MCP integration.
    - The `sales_agent.py` and `support_agent.py` files show the use of `LiteLlm` for model integration, which is a prerequisite for LiteLLM-based observability.
    - There is no explicit evidence of LangSmith integration (e.g., `langsmith.trace` decorators, `Client` initialization) in the provided code snippets.
    - The PromptFoo evaluation suite (`promptfoo.yaml`) is missing, and there's no implementation of an admin panel in the UI.
    _Suggestions:_
      - Integrate LangSmith tracing by initializing the LangSmith client and wrapping agent calls or tool executions with `@traceable` decorators or `with tracing_context()` blocks.
      - Create a `promptfoo.yaml` file with at least 10 test cases as specified in the project requirements, covering different agent flows and expected outcomes.
      - Implement the hidden admin panel in the Gradio UI to display live logs, eval results, and cost per session, as required by the task.
      - Ensure that the `LiteLlm` configuration is set up to report costs and model usage to LangSmith, which might involve specific environment variables or LiteLLM client settings.

## Code Quality
- **Overall:** 8.7/10
- Readability: 9.0/10
- Modularity: 8.5/10
- Naming: 8.5/10
  - Findings:
    - ecombot/demo.py uses clear and descriptive function and variable names, with helpful comments and a scenario guide string that improves understandability.
    - The code in ecombot/demo.py is well modularized with small helper functions (_wrap, _sep, _build_message, _ask) and separates concerns between running scenarios and REPL interaction.
    - In ecombot/session.py, the session service selection logic is encapsulated in get_session_service(), and make_runner() cleanly wraps agent creation with session management, showing good modularity.
    - Naming conventions are mostly consistent and follow Python standards (snake_case for functions and variables, PascalCase for classes). However, some private helper functions in demo.py use a leading underscore but are still used within the same module, which is acceptable but could be reconsidered.
    - The mcp_servers/inventory_server.py and orders_server.py files use clear naming and docstrings, but the orders_server.py snippet is incomplete, limiting full evaluation.
  - Suggestions:
    - In ecombot/demo.py, consider adding docstrings to all functions for consistency and better documentation.
    - Avoid using leading underscores for functions that are used throughout the module and are not strictly private; consider removing the underscore prefix from _wrap, _sep, _build_message, and _ask for clarity.
    - In ecombot/session.py, add type hints to get_session_service() return type for better type safety and clarity.
    - In mcp_servers/orders_server.py, ensure the file is complete and includes docstrings and comments similar to inventory_server.py for consistency.
    - Add more inline comments in complex logic areas, such as the async iteration in _ask(), to help readers unfamiliar with async generators understand the flow.

## Security
- Severity: medium
  - Issues:
    - WARN: Possible SELECT * FROM in ecombot/src/tools/order_tools.py:65
    - SQL Injection risk in ecombot/src/tools/order_tools.py:65: The `_try_db_query` function is called with a SQL query string and parameters. While the parameters are passed separately, the `SELECT *` could potentially expose more data than necessary if the `orders` table contains sensitive columns not intended for this function's purpose. This is less of a direct injection risk due to parameterized query, but more of a data exposure risk.
    - SQL Injection risk in ecombot/src/tools/order_tools.py:120: The `_try_db_query` function is called with a SQL query string and parameters. While the parameters are passed separately, the `SELECT status, customer_name` is specific, but still relies on the `_try_db_query` function which could be vulnerable if not implemented correctly (though in this snippet it appears to be using parameterized queries).
    - SQL Injection risk in ecombot/src/tools/order_tools.py:133: The `_try_db_execute` function is called with a SQL query string and parameters. This update statement uses parameterized queries, which mitigates direct injection. However, the overall reliance on constructing SQL strings, even with parameters, always carries a residual risk if not handled meticulously throughout the application.
  - Suggestions:
    - Replace `SELECT *` with explicit column names in `ecombot/src/tools/order_tools.py:65`. This follows the principle of least privilege, ensuring only necessary data is retrieved and reducing the risk of accidental sensitive data exposure.
    - Ensure that the `query_one` and `execute` functions in `src/services/db` are robustly implemented to prevent SQL injection, using parameterized queries for all user-supplied input. The current usage in `order_tools.py` appears to be passing parameters correctly, but the underlying implementation is critical.
    - Implement robust input validation and sanitization for all user-supplied inputs, especially `order_id`, beyond just format checking. While `_is_valid_order_id` checks the format, it doesn't prevent malicious input that might conform to the format but still exploit other vulnerabilities.
    - Consider adding more detailed logging for failed database operations (e.g., `_try_db_query`, `_try_db_execute`) to include error types or codes, but be cautious not to log sensitive information or full exception details in production environments that could aid an attacker.
    - Review the `ToolContext` and its state management. Ensure that sensitive information stored in `tool_context.state` is handled securely, especially if it persists across sessions or is exposed to users. Consider encryption or redaction for highly sensitive data.

## Summary
## Project Review Summary

This submission demonstrates a solid foundation in core AI agent concepts, but falls short on delivering the full end-to-end system required to pass the later modules — resulting in an overall score of 5.02/10.

**Where you shine:** Your **RAG integration and FastMCP server implementation** (scoring 9.0 and 9.5 respectively) are genuinely impressive — the ChromaDB embedding pipeline is cleanly structured, and your MCP servers show thoughtful error handling, including confirmation flows and timeout simulation. Equally strong is your **code quality** (8.7/10): the codebase is readable, well-modularized, and follows consistent naming conventions throughout.

**Where you need to focus:** The most critical gap is the **multi-agent architecture and advanced agent features** (Modules 6, 9, and 10). There is no Orchestrator agent, no Sales Agent with ReAct reasoning, and no LangSmith observability integration — these are foundational requirements for the upper modules, not optional extras. Second, the **UI and voice interface** (Modules 7 and 8) are entirely absent; while `chainlit` appears in your `requirements.txt`, no implementation exists. These two areas account for the majority of lost points.

You've clearly built strong instincts for tool design and prompt engineering — now it's time to connect all the pieces into a complete, running system. You've got the skills; trust the process and keep building! 🚀