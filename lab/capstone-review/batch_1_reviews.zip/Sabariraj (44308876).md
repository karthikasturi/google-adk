# Learner Project Review: Sabariraj

**Learner ID:** sabariraj_b6cfcf  
**Repo:** https://github.com/skysabari/ecombot-adk-course

**Overall Score:** ![score](https://img.shields.io/badge/Score-2.67/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 9.5/10)
    - The learner has successfully created a basic ADK agent (`support_agent.py`) that can accept text input and respond based on intent.
    - The agent's instructions (`support_instructions_v2.txt`) are well-defined, covering primary responsibilities, response guidelines, and out-of-scope topics.
    - The environment setup appears to be correct, with `dotenv` loading and `litellm` configured, indicating readiness for ADK Web and key usage.
    - The agent is initialized with a descriptive name and model, and the instruction set is correctly loaded from an external file.
    _Suggestions:_
      - While the prompt variations are not directly visible in the provided code, ensure that at least three distinct intent-based queries (e.g., order status, product query, return help) have been tested and yield appropriate responses.
      - Consider adding a simple test function within `support_agent.py` or a separate test file to programmatically verify basic intent recognition and response generation for the required prompt variations.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 9.5/10)
    - The `get_product_details` and `get_order_status` tools correctly save `current_product_id` and `current_order_id`/`customer_name` respectively to the `tool_context.state` for session memory.
    - The `cancel_order` tool effectively utilizes the session state to retrieve the `current_order_id` if not explicitly provided, demonstrating persistent session state across turns.
    - Both `product_tools.py` and `order_tools.py` include robust error handling for database issues, invalid inputs, and specific business logic failures (e.g., product not found, order already cancelled).
    - The tools return structured dictionaries with clear `found`/`cancelled` flags and detailed messages, fulfilling the structured response format requirement.
    _Suggestions:_
      - Consider adding a `lookup_product` tool alias for `get_product_details` if the prompt or agent expects that specific name, to ensure consistency with the project requirements.
      - While the current error handling is good, for a production system, logging specific error codes or more detailed exceptions could aid in debugging and monitoring.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 9.5/10)
    - The `embed_catalog.py` script successfully loads product and FAQ data, chunks it appropriately, and indexes it into ChromaDB.
    - The chunking logic for products is well-designed, breaking down product information into focused sub-chunks (overview, specs, shipping, warranty, support notes) which is excellent for targeted retrieval.
    - The script includes robust handling for selecting embedding functions, prioritizing OpenAI and falling back to OpenRouter if an OpenAI key is not found.
    - The ChromaDB collection is explicitly deleted and recreated on each run, ensuring a clean refresh of the knowledge base.
    _Suggestions:_
      - Consider adding a mechanism to update individual chunks or documents in ChromaDB rather than always deleting and recreating the entire collection, which can be inefficient for very large knowledge bases. This might involve checking for existing document IDs before adding.
      - While the current chunking is good, for very long product descriptions or FAQ answers, further sub-chunking or using a more advanced text splitter could improve retrieval precision for highly specific queries.
- **Implement LiteLLM Model Routing (eComBot v4)** (partial, 4.0/10)
    - The `support_agent.py` file imports `litellm` and uses `LiteLlm(model=MODEL)` which suggests an intention to use LiteLLM.
    - The `MODEL` variable is imported from `config.settings`, but the content of `settings.py` was not provided, making it unclear how models are defined or routed.
    - There is no explicit logic within the provided `support_agent.py` to route simple FAQ queries to `gpt-4o-mini` and complex ones to `gpt-4o`.
    - There is no visible implementation for automatic fallback to OpenRouter if the primary model fails.
    _Suggestions:_
      - Implement conditional logic within the agent or a wrapper function to dynamically select the LLM model based on the complexity or type of the user's query (e.g., using a classification step or keyword detection).
      - Configure LiteLLM's `model` parameter to accept a list of models for automatic fallback, or implement custom retry logic with different models/providers.
      - Ensure `config/settings.py` defines multiple models (e.g., `gpt-4o-mini`, `gpt-4o`, `openrouter/openai/gpt-4o`) and potentially a routing strategy.
- **Integrate FastMCP External APIs (eComBot v5)** (partial, 6.5/10)
    - The learner has implemented `get_order_status`, `cancel_order`, `get_product_details`, and `check_stock` functions, which are intended to act as external API integrations.
    - These functions interact with a PostgreSQL database, which is set up via `docker-compose.yml`, fulfilling the requirement of having external services.
    - Error handling for database exceptions and 'not found' scenarios is present in all tool functions, addressing the graceful failure requirement.
    - The current implementation uses direct database calls within the tool functions, rather than integrating with a FastMCP mock server as specified in the task description.
    _Suggestions:_
      - To fully meet the 'FastMCP External Integrations' requirement, refactor the tool functions (`order_tools.py`, `product_tools.py`) to make HTTP requests to a FastMCP mock server instead of directly querying the PostgreSQL database. This will simulate a true external API integration.
      - Implement specific API failure simulation tests (e.g., timeouts, 500 errors, invalid IDs) by configuring the FastMCP mock server to return these scenarios, and ensure the tool functions handle them gracefully.
      - Add a `get_invoice` tool to `order_tools.py` to complete the set of required order management functions.
- **Develop Multi-Agent Architecture (eComBot v6)** (fail, 2.0/10)
    - The provided code only shows a single `support_agent.py` file, which appears to be a continuation of the previous modules' work, not a multi-agent system.
    - There is no evidence of an 'Orchestrator' agent responsible for classifying intent and delegating tasks.
    - A 'Sales Agent' is mentioned in the task description but is not present in the provided code.
    - The `src/agents/agent.py` file simply imports `root_agent` from `support_agent.py`, indicating a single agent setup rather than a multi-agent architecture.
    _Suggestions:_
      - Create separate Python files for the Orchestrator agent and the Sales agent, similar to how `support_agent.py` is structured.
      - Implement the logic within the Orchestrator agent to classify user intent and then delegate the conversation to either the Support Agent or the Sales Agent.
      - Ensure that the `main` function or entry point of the application is updated to instantiate and utilize the Orchestrator for routing, rather than directly running the Support Agent.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided files (`requirements.txt`, `data/products.json`, `src/tools/order_tools.py`, `src/tools/product_tools.py`) do not contain any code related to building a Gradio chat interface or generative UI components.
    - There is no `src/ui/app.py` file or similar structure that would typically house the Gradio application.
    - The core requirements for this task, such as rendering distinct UI components, real-time streaming, and reflecting agent routing, are not addressed in the submitted code.
    - The `requirements.txt` only lists `chromadb`, which is not sufficient for a Gradio-based UI.
    _Suggestions:_
      - Create a `src/ui/app.py` file and implement the Gradio interface as described in the task requirements.
      - Add `gradio` to the `requirements.txt` file to enable the UI framework.
      - Integrate the agent's output into the Gradio interface to render product cards, order status cards, and other generative UI elements.
      - Implement real-time streaming for agent responses within the Gradio application.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code does not contain any implementation related to a voice interface.
    - There are no references to `faster-whisper`, `Piper TTS`, `LiveKit Agents`, or any audio processing libraries.
    - The `src/agents/support_agent.py` file shows a text-based input loop, indicating no voice integration.
    - The `requirements.txt` only lists `chromadb`, which is insufficient for voice processing.
    _Suggestions:_
      - Integrate `faster-whisper` for Speech-to-Text (STT) to convert audio input into text.
      - Incorporate `Piper TTS` for Text-to-Speech (TTS) to convert agent responses into audio.
      - Utilize `LiveKit Agents` or a similar framework to orchestrate the real-time voice pipeline, handling audio streaming and interaction.
      - Add a mic button and live transcription display to the Gradio UI as specified in the requirements.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided code snippets do not include any files related to a 'Sales Agent'.
    - There is no evidence of a ReAct reasoning loop implementation.
    - No reflection mechanism for rejected recommendations is present in the provided code.
    - The `support_agent.py` file is the only agent-related file provided, and it does not contain the required ReAct logic for a Sales Agent.
    _Suggestions:_
      - Create a dedicated `sales_agent.py` file within the `src/agents/` directory.
      - Implement the ReAct pattern within the `sales_agent.py` by defining a clear thought process (e.g., identify budget, filter catalog, compare specs, recommend) using tools and internal reasoning.
      - Add logic for reflection and adjustment if a recommendation is rejected, potentially by modifying the agent's internal state or prompt.
      - Ensure the `orchestrator.py` (from M6) is correctly routing sales-related queries to this new Sales Agent.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - The provided `support_agent.py` file does not contain any explicit LangSmith integration or configuration.
    - There is no evidence of PromptFoo test cases (`promptfoo.yaml`) or their execution within the provided files.
    - The code does not include any implementation for an admin panel or a mechanism to display live logs, eval results, or cost per session.
    - The `requirements.txt` only lists `chromadb`, which is insufficient for LangSmith or LiteLLM's full capabilities.
    _Suggestions:_
      - Integrate LangSmith by setting `LANGCHAIN_TRACING_V2=true` and `LANGCHAIN_API_KEY` environment variables, and ensuring `langsmith` is installed. The ADK `LlmAgent` should automatically pick this up if configured correctly.
      - Create a `promptfoo.yaml` file in the `evals/` directory with at least 10 test cases as specified in the project requirements.
      - Implement the Gradio admin panel functionality to display observability metrics (logs, eval results, cost per session) as described in the requirements.
      - Update `requirements.txt` to include `langsmith` and any other necessary libraries for LiteLLM and observability features.

## Code Quality
- **Overall:** 9.0/10
- Readability: 9.5/10
- Modularity: 9.0/10
- Naming: 8.5/10
  - Findings:
    - src/tools/order_tools.py uses clear and descriptive function and variable names, with helpful docstrings explaining purpose and arguments.
    - Error handling in database queries is consistent and logs errors with context, improving maintainability (order_tools.py, product_tools.py).
    - Functions are well-scoped and focused on single responsibilities, avoiding god functions (order_tools.py, product_tools.py).
    - Naming conventions are mostly consistent with Python standards, but some variable names like 'oid' and 'pid' could be more descriptive (order_tools.py, product_tools.py).
    - The support_agent.py file is well-structured with clear separation of concerns and detailed instructions for agent behavior, but the file is truncated and incomplete in the sample.
  - Suggestions:
    - Replace abbreviations like 'oid' and 'pid' with more descriptive names such as 'order_id_clean' or 'product_id_clean' for clarity.
    - Add type hints for all function parameters and return types consistently across all files to improve code clarity and tooling support.
    - Consider extracting repeated error message patterns or database query logic into helper functions to reduce duplication and improve modularity.
    - Add more inline comments in complex conditional blocks (e.g., cancel_order status checks) to explain business rules for future maintainers.
    - Complete the truncated support_agent.py file and ensure all async functions and imports are properly closed and handled.

## Security
- Severity: high
  - Issues:
    - Exposed credentials or API keys: src/services/db.py:30 - Default PostgreSQL credentials ('pg_secret') are hardcoded and exposed if environment variables are not set.
    - Unsafe input handling / injection risks: src/tools/product_tools.py:39 - Using SELECT * FROM can return more data than necessary, potentially including sensitive columns if added later. It's better to explicitly list required columns.
    - Unsafe input handling / injection risks: src/services/db.py:144 - Using SELECT * FROM can return more data than necessary, potentially including sensitive columns if added later. It's better to explicitly list required columns.
  - Suggestions:
    - Ensure all sensitive credentials (like PG_PASSWORD) are always loaded from secure environment variables or a secrets management system, and never hardcoded with default values.
    - For all SELECT statements, explicitly list the columns required instead of using `SELECT *`. This improves clarity, performance, and prevents accidental exposure of sensitive data if new columns are added to the table.
    - Consider implementing a more robust secrets management strategy for production environments, such as AWS Secrets Manager, Azure Key Vault, or HashiCorp Vault, instead of relying solely on .env files.

## Summary
## Project Review Summary

This submission shows a genuinely strong foundation in the early modules, but significant gaps in the later tasks have substantially impacted the overall score.

**Where you excelled:** Your work on the core agent setup and tooling (Modules 1–3) is impressive — the instruction design in `support_instructions_v2.txt` is thorough, and the session memory implementation using `tool_context.state` across your order and product tools demonstrates a solid understanding of stateful agent design. Additionally, your code quality stands out: functions are well-scoped, error handling is consistent, and the RAG chunking strategy in `embed_catalog.py` reflects thoughtful architectural decisions.

**Where you need to focus:** The two most critical gaps are the **multi-agent architecture (Module 6)** and everything from **Module 7 onward** — the Generative UI, Voice Interface, ReAct Sales Agent, and Observability tasks show no submitted implementation. These aren't minor oversights; they represent roughly half the project scope. Separately, the **hardcoded database credentials** in `db.py` are a high-severity security issue that must be addressed before any production deployment.

You've clearly demonstrated you *can* write clean, well-structured agent code — now it's about completing the full vision. Push through the remaining modules; the skills you've built in the first half will carry you further than you might expect. Keep going! 💪