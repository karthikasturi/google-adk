# Learner Project Review: Jeevaa Jegathambal Murugarajan

**Learner ID:** jeevaa_jegathambal_murugarajan_28ec7a  
**Repo:** https://github.com/jeevaa1799-stark/ADK_lab_Capstone_eCombot

**Overall Score:** ![score](https://img.shields.io/badge/Score-2.84/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 8.5/10)
    - The learner has created multiple prompt variations for the support agent, demonstrating an understanding of prompt engineering.
    - The `support_instructions_V_top.txt` prompt is comprehensive, covering primary goals, scope, out-of-scope handling, guidelines, unknown information, response patterns, and even initial tool usage rules (though tools are for M2).
    - The prompts clearly define the agent's role as an 'expert customer support agent for an electronics e-commerce company'.
    - The prompts emphasize crucial aspects like not guessing, asking clarifying questions, and maintaining a professional tone, which are foundational for a reliable agent.
    _Suggestions:_
      - While multiple prompt variations are good for testing, ensure that the final chosen prompt for v1 is clearly identified and integrated into the agent's configuration.
      - For v1, focus primarily on intent classification and basic responses. The detailed tool usage rules in `support_instructions_V_top.txt` are excellent for future modules but might be slightly ahead for a 'basic' agent without tools yet.
      - Consider adding a small section in the README or a separate document explaining the rationale behind the different prompt variations and which one is intended for the initial v1 deployment.
- **Implement Tools and Session Memory (eComBot v2)** (pass, 8.5/10)
    - The learner has successfully implemented `get_order_status` and `lookup_product` tools, demonstrating tool calling.
    - Structured output is provided for both order status and product lookup, returning dictionaries with relevant details.
    - Session state is utilized to remember `last_order_id`, `customer_name`, `last_product_id`, and `last_product_name` across turns, indicating persistence.
    - The `order_tools_v2.py` file shows a transition from mock data to PostgreSQL integration, fulfilling the 'persistent via Redis' requirement by using a database for durable storage, although Redis itself isn't explicitly used for session state in the provided snippets.
    _Suggestions:_
      - While the database integration provides persistence, explicitly demonstrate Redis for session state as per the requirement, or clarify if the database is intended to replace Redis for this module's session state.
      - Add specific failure scenario tests for `lookup_product` (e.g., product not found, empty product name) to ensure robust error handling, similar to what's done for `get_order_status` and `cancel_order`.
      - Ensure that the `tool_context.state` is indeed backed by Redis for session persistence, as the current implementation appears to use `tool_context.state` which might be in-memory unless configured otherwise by the ADK framework.
- **Integrate RAG Knowledge Base (eComBot v3)** (fail, 1.0/10)
    - The provided code does not show any integration of ChromaDB or a RAG system.
    - The `support_instructions_v3.txt` file contains general instructions for an agent but no specific directives for RAG or hallucination control.
    - The `product_tools.py` file uses a direct SQL query to a `products` table, which is not a RAG implementation.
    - There is no evidence of a knowledge base (product catalog or FAQ) being indexed or retrieved using vector embeddings.
    _Suggestions:_
      - Implement ChromaDB for vector storage and indexing of product catalog and FAQ data.
      - Develop a retriever component that queries ChromaDB based on user input and integrates the retrieved context into the agent's prompt.
      - Modify the agent's prompt to explicitly instruct it to use the retrieved context and to gracefully handle cases where information is not found (hallucination guard).
      - Replace the direct database query in `lookup_product` with a RAG-based approach for product information retrieval.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation of LiteLLM for model routing or fallback.
    - There are no configuration files or code demonstrating the use of multiple LLM providers (e.g., OpenAI and OpenRouter).
    - The `support_instructions_v4.txt` file is a prompt update, but it does not relate to model routing.
    - The `test_order_tools_v2.py`, `test_support_agent_manual.md`, and `test_history.py` files are related to previous modules (tools, testing, session memory) and do not address LiteLLM routing.
    _Suggestions:_
      - Integrate LiteLLM into the agent's LLM calls. This typically involves wrapping the LLM instantiation with LiteLLM's client.
      - Configure LiteLLM to use at least two providers (e.g., OpenAI and OpenRouter) and define routing logic based on query complexity or other criteria.
      - Implement a mechanism to simulate model failures and verify that LiteLLM correctly falls back to the secondary provider.
      - Add tests to confirm that different types of queries (e.g., simple FAQ vs. complex complaints) are routed to the appropriate models as specified in the requirements.
- **Integrate FastMCP External APIs (eComBot v5)** (fail, 2.0/10)
    - The provided code `order_tools_v1.py` uses a hardcoded `MOCK_ORDERS` dictionary, which does not represent an integration with FastMCP mock servers.
    - There is no evidence of FastMCP being used or configured in the provided files.
    - The task requires implementing `cancel_order`, `get_invoice`, and `check_stock` tools, but only `get_order_status` is present, and it's a mock implementation.
    - Error handling for API failures (timeouts, 500 errors) is not implemented, as the current tools are purely in-memory mocks.
    _Suggestions:_
      - Implement the FastMCP mock servers as described in the module requirements. This typically involves creating separate Python files for the order and inventory services that expose endpoints.
      - Refactor the `order_tools.py` to make actual HTTP requests to the FastMCP mock servers for `get_order_status`, `cancel_order`, and `get_invoice`.
      - Add a new tool, `check_stock`, that interacts with the FastMCP inventory server.
      - Introduce error handling mechanisms (e.g., try-except blocks for network errors, checking HTTP status codes) when making requests to the FastMCP servers.
- **Develop Multi-Agent Architecture (eComBot v6)** (fail, 3.0/10)
    - The provided files only contain various versions of `support_instructions.txt`.
    - There is no evidence of an Orchestrator agent, a Sales Agent, or the splitting of the single agent into multiple distinct agents.
    - The core requirement of implementing a Planner–Executor pattern and task delegation is not met.
    - No code demonstrating routing logic (e.g., 'Where is my order?' → Support Agent; 'What phone should I buy?' → Sales Agent) is present.
    _Suggestions:_
      - Create separate agent files (e.g., `orchestrator.py`, `support_agent.py`, `sales_agent.py`) to define each agent's behavior and tools.
      - Implement an Orchestrator agent that can classify user intent and delegate tasks to either the Support Agent or the Sales Agent.
      - Define the specific responsibilities and tools for the Support Agent (order, returns) and the Sales Agent (product discovery, recommendations).
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets do not include any UI-related files (e.g., `eCombot/src/ui/app.py` or Gradio-specific code).
    - The `agent_day03.txt` file defines an `LlmAgent` and its tools, but this is part of the agent's backend logic, not the generative UI itself.
    - The `support_instructions_v3.txt` is a prompt for the agent, which is also backend logic.
    - The `requirements.txt` lists `google-adk`, `litellm`, `python-dotenv`, `redis`, `psycopg2-binary`, and `sqlalchemy`, but no UI libraries like `gradio` are present.
    _Suggestions:_
      - To address this task, the learner needs to create a Gradio application (`eCombot/src/ui/app.py` as per the recommended structure) that interacts with the agent.
      - Implement the Gradio interface to display chat history, and specifically design components for product cards, order status cards, agent routing traces, RAG source tags, and a LiteLLM model badge.
      - Ensure real-time streaming of agent responses is integrated into the Gradio UI.
      - Add `gradio` to the `requirements.txt` file.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a voice interface.
    - There are no references to `faster-whisper`, `Piper TTS`, `LiveKit Agents`, or any audio processing libraries.
    - The files `agent_day03.txt` and `agent.py` seem to be variations of an ADK agent definition, focusing on tools and instructions, not voice integration.
    - The `support_instructions_v2.txt` file is a prompt for the agent's behavior, which is unrelated to the voice interface implementation.
    _Suggestions:_
      - To implement the voice interface, the learner needs to integrate STT (Speech-to-Text) and TTS (Text-to-Speech) components, likely using `faster-whisper` and `Piper TTS` as specified.
      - The orchestration of the voice pipeline, including real-time streaming and handling of audio input/output, would typically involve a framework like LiveKit Agents.
      - The Gradio UI (`eCombot/src/ui/app.py` as per the repository structure) would need modifications to include a microphone button and display live transcription.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a Sales Agent.
    - There is no evidence of a ReAct reasoning loop, reflection mechanism, or any logic for filtering, comparing, or recommending products.
    - The `agent_day03.txt` file appears to be an early version of a Support Agent, not a Sales Agent, and it lacks the complexity required for this task.
    - The `requirements.txt` file lists basic ADK and LiteLLM, but no specific libraries or frameworks that would typically be used for implementing complex reasoning or reflection (e.g., specific ReAct libraries or advanced prompt engineering frameworks).
    _Suggestions:_
      - Create a dedicated `sales_agent.py` file within the `src/agents/` directory as per the recommended repository structure.
      - Implement the ReAct pattern within the Sales Agent, which typically involves defining a 'thought', 'action', and 'observation' loop. This will require careful prompt engineering and potentially custom tools for filtering and comparing products.
      - Develop a mechanism for the Sales Agent to reflect on rejected recommendations and adjust its strategy. This could involve adding a 'reflection' step to the ReAct loop.
      - Integrate the Sales Agent with the product catalog and RAG system (from Module 3) to ground its recommendations in actual product data.
- **Add Observability and Evaluation (eComBot v10)** (fail, 1.0/10)
    - The provided files do not show any implementation of LangSmith tracing. There are no imports or configurations related to LangSmith.
    - There is no evidence of a PromptFoo eval suite. The `eCombot/tests/test_support_agent_manual.md` file contains manual test scenarios, not an automated PromptFoo configuration.
    - The concept of an 'admin panel' for live logs, eval results, and cost per session is not present in the provided code.
    - The code still uses `LiteLlm` with a single model (`openrouter/google/gemini-2.5-flash`), indicating that model routing and cost tracking per session (which would be visible in LangSmith) are not yet implemented or configured for observability.
    _Suggestions:_
      - Integrate LangSmith by configuring the ADK agents to use LangSmith for tracing. This typically involves setting up environment variables and potentially wrapping agent calls.
      - Create a `promptfoo.yaml` file in the `evals/` directory with at least 10 test cases as specified in the project requirements. Run PromptFoo and ensure the tests pass.
      - Develop the 'admin panel' within the Gradio UI to display relevant observability metrics like LangSmith traces, PromptFoo results, and session costs. This might involve querying LangSmith APIs or storing local logs.
      - Ensure that LiteLLM is configured for model routing as per Module 4, and that this routing is reflected in LangSmith traces for cost and model usage tracking.

## Code Quality
- **Overall:** 8.3/10
- Readability: 8.5/10
- Modularity: 8.0/10
- Naming: 8.5/10
  - Findings:
    - eCombot/src/tools/order_tools_v1.py uses clear and descriptive function names and includes docstrings, but lacks inline comments explaining logic.
    - eCombot/src/tools/order_tools_v2.py has some code duplication in SQL queries and repeated patterns for order lookup and verification.
    - eCombot/src/tools/product_tools.py is concise and readable, but could benefit from a brief docstring for the main function.
    - eCombot/src/services/db.py handles connection pooling and query execution well, but lacks error handling and logging which affects robustness.
    - eCombot/src/agents/agent.py is clean and well-structured, with consistent naming and clear separation of concerns.
  - Suggestions:
    - Add brief docstrings to all public functions, especially in product_tools.py and session_service.py, to improve clarity.
    - Refactor repeated SQL query patterns in order_tools_v2.py into helper functions to reduce duplication and improve modularity.
    - Introduce error handling and logging in db.py to handle database exceptions gracefully and aid debugging.
    - Add inline comments in complex or non-obvious code sections, such as order status checks and cancellation logic, to improve readability.
    - Consider consistent use of type hints across all functions for better code clarity and tooling support.

## Security
- Severity: medium
  - Issues:
    - Hardcoded default credentials in eCombot/.env.example: REDIS_PASSWORD=CHANGE_ME, POSTGRES_USER=CHANGE_ME, POSTGRES_PASSWORD=CHANGE_ME. While this is an example file, it sets a poor precedent and could be accidentally used in production.
    - Sensitive information (API key) mentioned in eCombot/.env.example: OPENROUTER_API_KEY=your-openrouter-api-key-here. Although it's an example, it highlights the presence of an API key that needs secure handling.
    - Potential for insecure Redis configuration in eCombot/docker-compose.yml: The Redis password is passed directly as an environment variable in the command line and healthcheck, which can be visible to other processes on the host system. While using `REDIS_PASSWORD` is better than hardcoding, it's still not the most secure way to pass secrets to Redis.
    - Potential for insecure PostgreSQL configuration in eCombot/docker-compose.yml: PostgreSQL credentials are passed directly as environment variables, which can be visible to other processes on the host system.
  - Suggestions:
    - For `.env.example`, ensure that all placeholder values for sensitive information (like passwords and API keys) are clearly marked as needing to be changed and are not easily mistaken for production-ready values. Consider using more complex placeholder values or explicitly stating 'DO_NOT_USE_IN_PRODUCTION' for passwords.
    - Emphasize in documentation that `.env.example` is for development setup only and that production environments should use more secure secret management solutions.
    - For Redis, consider using Docker secrets or a dedicated secret management service (e.g., HashiCorp Vault, AWS Secrets Manager, Kubernetes Secrets) to inject the `REDIS_PASSWORD` more securely, rather than directly via environment variables in the command.
    - For PostgreSQL, similarly, consider using Docker secrets or a dedicated secret management service to manage `POSTGRES_USER` and `POSTGRES_PASSWORD` instead of direct environment variables.
    - Ensure that the `.env` file, which contains actual secrets, is correctly ignored by version control systems (as it is in `.gitignore`).
    - Review the `REDIS_PASSWORD` and `POSTGRES_PASSWORD` values in the actual `.env` file (not provided here) to ensure they are strong, unique, and not default values.

## Summary
## Project Review Summary

This submission shows genuine promise in its early foundational work, but significant portions of the project remain unimplemented, resulting in an overall score of 2.84/10 that doesn't yet reflect the full scope of what was required.

**Where you shine:** Your prompt engineering work for the basic support agent (eComBot v1) is a real highlight — the `support_instructions_V_top.txt` demonstrates thoughtful structure, covering scope, tone, and edge cases with maturity beyond what's expected at this stage. Additionally, your code quality across the implemented modules is commendable: clean naming conventions, readable structure, and a solid database-backed tool implementation in `order_tools_v2.py` show you can write professional-grade code when you engage with a task.

**Where you must focus next:** The most critical gap is **module completion** — six of ten tasks scored at or near zero, with RAG integration, LiteLLM routing, multi-agent architecture, and the UI/voice layers entirely missing. Submitting placeholder files or prompt variations in place of functional code suggests time management or scope-planning challenges worth addressing directly. Second, **security practices** need attention; credentials in configuration files and unprotected environment variables are habits to correct now before they become production risks.

You clearly have the technical instincts to do this work well — the quality of what *is* built proves that. Regroup, tackle the remaining modules one at a time, and don't hesitate to ask for support. You've got this. 💪