# Learner Project Review: Mansi Prakash Kumar

**Learner ID:** mansi_prakash_kumar_082a3f  
**Repo:** https://github.com/MansiMali23/GoogleAdkProject

**Overall Score:** ![score](https://img.shields.io/badge/Score-4.92/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 9.0/10)
    - The learner has successfully created multiple basic ADK agents, demonstrating an understanding of the core `LlmAgent` class and instruction-based prompting.
    - The `friendly_support` and `scope_limited_support` agents showcase different prompt behavior variations, fulfilling the requirement for testing at least 3 variations.
    - The use of `.env` for API keys and `Path(__file__).parent / "instruction.txt"` for externalizing instructions demonstrates good practice for environment setup and prompt management.
    - The `scenario_03.py` script explicitly tests in-scope vs. out-of-scope queries, which directly addresses the concept of prompt-defined boundaries for an agent.
    _Suggestions:_
      - While `day03/agent.py` introduces tools, for a pure 'v1' evaluation, it would be beneficial to see a clear separation or a dedicated `v1` agent that strictly adheres to the 'no tools' requirement for this module. The current `day03/agent.py` already includes tools, which is beyond the scope of v1.
      - Ensure that the `instruction.txt` files for each agent are distinct and clearly define the persona and scope, as this is the primary mechanism for prompt behavior variation in v1.
- **Implement Tools and Session Memory (eComBot v2)** (partial, 6.5/10)
    - The `tools.py` file defines `get_order_status` and `lookup_product` functions, which are intended to be tool-integrated. These functions correctly use `tool_context.state` to store session information.
    - The `get_order_status` and `lookup_product` tools return structured dictionaries, indicating an attempt at structured output.
    - The `save_customer_name` and `get_session_summary` tools demonstrate the use of `tool_context.state` for persisting session data within the in-memory context.
    - The `day02/session_memory/agent.py` file explicitly mentions `InMemorySessionService` and its role in maintaining conversation history, which aligns with the session memory requirement.
    _Suggestions:_
      - While tools are defined, the provided code snippets do not show how these tools are actually integrated into an ADK agent (e.g., using `LlmAgent(tools=[...])`). This is crucial for 'at least 1 tool-integrated agent working'.
      - The prompt does not explicitly demonstrate 'minimum 3 failure scenario tests passing' for the tools. While the tools have basic error handling (e.g., 'Order not found'), dedicated test cases or a clear demonstration of these scenarios being handled by an agent are missing.
      - The requirement specifies 'first in-memory, then persistent via Redis'. The current code only shows in-memory session state. Integration with Redis for persistent session state is a key missing component for full completion of this task.
- **Integrate RAG Knowledge Base (eComBot v3)** (pass, 8.5/10)
    - The `day05/agent.py` file successfully implements a RAG-grounded agent using `semantic_search` to retrieve context.
    - The `_format_context` function clearly distinguishes between cases where relevant context is found and when it's not, providing a clear instruction for the model.
    - The `_build_instruction` function dynamically constructs the agent's instruction by embedding retrieved context, ensuring the agent grounds its responses.
    - A 'plain_agent' is provided for comparison, which is a good practice to demonstrate the value of RAG.
    _Suggestions:_
      - Ensure that the `kb.py` file (which is not provided here but is referenced) correctly indexes the product catalog and FAQ into ChromaDB.
      - Add specific unit tests for the hallucination guard, beyond just the `_format_context` logic, to verify the agent's behavior when no relevant context is found.
      - While the `_GROUNDING_RULES` are good, consider making the 'say so plainly' fallback message configurable or more explicit in the prompt to ensure consistent phrasing.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 0.0/10)
    - The provided code snippets do not demonstrate any implementation of LiteLLM model routing.
    - There is no evidence of conditional logic to route queries to different models (e.g., `gpt-4o-mini` for simple FAQs and `gpt-4o` for complex flows).
    - The code consistently uses a single model, `openrouter/google/gemini-2.5-flash`, across all provided agent files.
    - There is no configuration or logic for automatic fallback to OpenRouter if a primary model fails.
    _Suggestions:_
      - Introduce a mechanism (e.g., a custom LiteLLM router or conditional logic within the agent) to dynamically select models based on query complexity or intent.
      - Configure LiteLLM with multiple providers (OpenAI and OpenRouter) and implement fallback logic as described in the task requirements.
      - Create a dedicated configuration file or section to define model routing rules and fallback sequences.
- **Integrate FastMCP External APIs (eComBot v5)** (pass, 9.5/10)
    - The learner has successfully implemented two FastMCP mock servers: `order_server.py` for order management and `product_server.py` for product search.
    - The `order_server.py` includes `get_order_status`, `get_order_details`, `list_orders`, and `cancel_order` tools, demonstrating a comprehensive set of order management functionalities.
    - The `product_server.py` implements a `find_products` tool with filtering capabilities by city, max price, and proximity.
    - Both servers include basic error handling for 'not found' scenarios (e.g., `_not_found` function in `order_server.py`) and `product_server.py` simulates timeouts using `PRODUCT_SEARCH_DELAY_SECONDS`.
    _Suggestions:_
      - While 'not found' scenarios are handled, explicit error handling for other API failure types (e.g., 500 errors, network issues) could be demonstrated more robustly within the tool functions themselves, perhaps by raising specific exceptions that the agent can catch.
      - Consider adding more diverse mock data to `_BOOKINGS` and `_PRODUCTS` to cover edge cases and a wider range of scenarios for testing.
- **Develop Multi-Agent Architecture (eComBot v6)** (partial, 4.0/10)
    - The provided code snippets show individual agent definitions (friendly_support, scope_limited_support, aria) and a routing mechanism (routing.py) for LiteLLM models, but not for agent delegation.
    - The `routing.py` file implements model routing based on query complexity (`classify_query`), which is relevant for M4 (LiteLLM Model Routing) but not directly for M6's multi-agent delegation.
    - There is no clear implementation of an Orchestrator agent that classifies intent and then delegates tasks to a Support Agent or a Sales Agent.
    - The `root_agent` in each `agent.py` file suggests a single agent setup, rather than a multi-agent system where an orchestrator delegates to specialized agents.
    _Suggestions:_
      - Create a dedicated 'Orchestrator' agent that takes the initial user query. This agent's primary role should be to determine the user's intent (e.g., 'order status', 'product recommendation') and then delegate the query to the appropriate specialized agent (Support Agent or Sales Agent).
      - Define separate `Support Agent` and `Sales Agent` classes or instances, each with their own instructions and potentially tools, as described in the module requirements.
      - Implement the delegation logic within the Orchestrator. This could involve using ADK's agent-to-agent communication features or simply calling the appropriate agent's processing method based on the classified intent.
      - Ensure that the routing logic for agent delegation is distinct from the LiteLLM model routing. While model routing is important, the core of M6 is about routing *between agents*.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided code snippets (day03/agent.py, day02/model_params/agent.py, day05/agent.py) do not contain any Gradio UI implementation.
    - There is no evidence of rich UI components like product cards, order status cards, or RAG source tags being rendered.
    - Real-time streaming of agent responses is not implemented in the provided agent definitions.
    - The code does not demonstrate any mechanism for the UI to reflect agent routing or graceful fallback for unstructured output.
    _Suggestions:_
      - Implement a Gradio application (e.g., in `src/ui/app.py` as per the recommended structure) to serve as the chat interface.
      - Design and implement custom Gradio components or use existing ones to render rich UI elements like product cards and order status cards based on structured outputs from the agents.
      - Integrate real-time streaming capabilities into the Gradio interface to display agent responses as they are generated.
      - Ensure the UI can display information about which agent responded (Orchestrator, Support, Sales) and handle various output formats gracefully.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to a voice interface.
    - There are no references to `faster-whisper`, `Piper TTS`, `LiveKit Agents`, or any audio processing libraries.
    - The code primarily focuses on basic ADK agent setup with LiteLLM for text-based interactions.
    - The `day02` examples are foundational for agent definition but do not address the voice interface requirements of Module 8.
    _Suggestions:_
      - Begin by integrating a Speech-to-Text (STT) library like `faster-whisper` to convert audio input into text.
      - Incorporate a Text-to-Speech (TTS) library such as `Piper TTS` to convert agent responses into audio.
      - Explore `LiveKit Agents` for orchestrating the real-time voice pipeline, including handling mic input and speaker output.
      - Add a mic button and live transcription display to the Gradio UI as specified in the requirements.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation of a ReAct reasoning loop.
    - There is no evidence of reflection on rejected recommendations within the given files.
    - The code does not include any UI components for a collapsible 'Agent Reasoning' panel.
    - The `day05/agent.py` and `day07/agent.py` files primarily focus on RAG and model routing, respectively, without addressing the ReAct pattern for the Sales Agent.
    _Suggestions:_
      - Implement a ReAct loop within the Sales Agent by defining a sequence of thought, action, and observation steps.
      - Add logic for the Sales Agent to analyze user feedback (e.g., rejection of a recommendation) and adjust its reasoning or approach accordingly.
      - Integrate a UI element (e.g., in Gradio) that can display the agent's thought process during the ReAct loop, making it collapsible.
      - Ensure that the Sales Agent's decision-making process, including budget identification, catalog filtering, comparison, and recommendation, is explicitly structured using the ReAct pattern.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - The provided code snippets do not show any implementation related to LangSmith tracing, PromptFoo evaluation, or an admin panel.
    - The files `day02/model_params/agent.py`, `day02/session_memory/agent.py`, `day05/session.py`, `day05/agent.py`, and `day05/requirements.txt` are from earlier modules (Day 02 and Day 05) and focus on model parameters, session memory, and RAG, not observability or evaluation.
    - There are no explicit configurations for LangSmith, no PromptFoo YAML files, and no UI code for an admin panel.
    - The `requirements.txt` file does not include any dependencies that would typically be used for LangSmith or PromptFoo (e.g., `langsmith`, `promptfoo`).
    _Suggestions:_
      - Implement LangSmith tracing by configuring the `LANGCHAIN_TRACING_V2` and `LANGCHAIN_API_KEY` environment variables and ensuring ADK agents are instrumented for tracing.
      - Create a `promptfoo.yaml` file with at least 10 test cases covering the specified scenarios for eComBot.
      - Develop a hidden admin panel within the Gradio UI (from Module 7) to display live logs, evaluation results, and cost per session.
      - Update the `requirements.txt` to include `langsmith` and `promptfoo` dependencies.

## Code Quality
- **Overall:** 9.0/10
- Readability: 9.0/10
- Modularity: 9.0/10
- Naming: 9.0/10
  - Findings:
    - In demo.py, functions and variables have clear, descriptive names and the code includes helpful docstrings and comments explaining scenarios and usage (demo.py).
    - The code is well modularized: demo.py handles orchestration and scenarios, kb.py encapsulates knowledge base logic, and session.py manages session creation, keeping concerns separated (demo.py, kb.py, session.py).
    - Naming conventions are consistent and follow Python standards, using snake_case for functions and variables, and PascalCase for classes (demo.py, session.py).
    - Some helper functions in demo.py (e.g., _wrap, _sep) are small and focused, aiding readability and reuse (demo.py).
    - The kb.py module is well documented and clearly separates embedding and collection management logic (kb.py).
  - Suggestions:
    - Add type hints to all functions for improved clarity and static analysis, e.g., in demo.py and kb.py.
    - Consider adding more inline comments in complex async functions like _ask to explain event handling logic (demo.py).
    - In demo.py, the _wrap function uses a fixed prefix and width; consider making prefix configurable or document its purpose more explicitly.
    - In session.py, document the return types of get_session_service and make_runner more explicitly in docstrings.
    - Add error handling around external calls (e.g., embedding API calls in kb.py) to improve robustness and provide clearer failure modes.

## Security
- Severity: low
  - Issues:
    - Possible SELECT * FROM in day04/tools.py:28
    - Possible eval( in day06/tests/test_kb.py:101
  - Suggestions:
    - In `day04/tools.py:28`, replace `SELECT *` with an explicit list of column names to retrieve only necessary data. This improves performance and reduces the risk of exposing sensitive data if new columns are added to the `orders` table.
    - The `eval()` warning in `day06/tests/test_kb.py:101` is a false positive as it refers to a test file and the line number likely points to a comment or string. No action is needed for this specific instance.
    - Ensure that `db.py` (which provides `execute`, `query_all`, `query_one`) properly sanitizes inputs and uses parameterized queries to prevent SQL injection. While the `tools.py` file uses parameterized queries, the underlying `db.py` implementation is critical.
    - Review logging practices in `day04/tools.py` to ensure no sensitive information (like full order details, customer names, or product details beyond what's necessary for debugging) is logged, especially in error messages. For example, `log.error("DB error in get_order_status: %s", exc)` could potentially log sensitive database error details.

## Summary
## Project Review Summary

This submission shows genuine promise in foundational ADK concepts and external API integration, but significant gaps in the later modules bring the overall score down to 4.92/10 — reflecting a project that is roughly half-complete.

**Strongest Areas:**
Your work on the **Basic Support Agent (v1, 9.0/10)** and **FastMCP External API integration (v5, 9.5/10)** stands out clearly. The v1 agents demonstrate solid understanding of prompt-driven behavior, environment management, and instruction externalization. The FastMCP servers are well-structured, include meaningful error handling, and show real attention to realistic tool design.

**Most Important Areas for Improvement:**
First, **Modules 6 through 10 are largely unimplemented** — LiteLLM model routing, multi-agent orchestration, Generative UI, Voice Interface, ReAct, and Observability all scored zero or near-zero. These aren't minor gaps; they represent the architectural backbone of a production-grade agent system. Second, the **Tools and Session Memory task (v2)** needs completion — tools are defined but never wired into an agent, and Redis-based persistent session state is entirely missing.

The code quality score (9.0) tells an important story: when you *do* write code, you write it well. The modularity, naming conventions, and documentation are genuinely strong. Now it's time to apply that same craft to the remaining modules. You have a solid foundation — keep building! 🚀