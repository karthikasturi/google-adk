# Learner Project Review: Aravindh Mahendran

**Learner ID:** aravindh_mahendran_1e7dd7  
**Repo:** https://github.com/Aravindhmahe/ecom-bot

**Overall Score:** ![score](https://img.shields.io/badge/Score-2.71/10-blue)

## Task Results
- **Build Basic Support Agent (eComBot v1)** (pass, 8.5/10)
    - The `build_agent` function in `src/models.py` provides a clean abstraction for creating LlmAgent instances, centralizing model configuration.
    - The `support_instructions_v1.txt` file clearly defines the role and limitations of the eComBot v1 agent, specifically noting the absence of external tools and live data access.
    - The use of `openrouter/google/gemini-2.5-flash` as the default model indicates an awareness of cost-effective and performant LLMs, aligning with production readiness goals.
    - The `support_instructions_v3.txt` file, while not directly for v1, shows a clear progression plan for the agent's capabilities, which is good for the overall project structure.
    _Suggestions:_
      - Ensure that the `build_agent` function is actually being called to instantiate the v1 agent with the `support_instructions_v1.txt` content. The provided files only show the definition, not the instantiation.
      - While `support_instructions_v1.txt` outlines the agent's limitations, consider adding a specific instruction within the prompt to politely redirect or inform the user when a query requires capabilities beyond v1 (e.g., 'I can't look up live order status yet, but I can help with general product information.').
      - For testing the 'Minimum 3 prompt behavior variations', it would be beneficial to have a simple test script or a clear manual testing guide to demonstrate these variations.
- **Implement Tools and Session Memory (eComBot v2)** (partial, 6.5/10)
    - The `lookup_product` tool is implemented and correctly uses `ToolContext.state` to store `last_lookup_key` and `current_product_id`, demonstrating session state management within the tool.
    - The `lookup_product` tool returns structured output including `product_id`, `name`, `category`, `price`, `stock_status`, and `description`, fulfilling the structured response format requirement.
    - Error handling is present for empty product names and database errors, returning informative messages, which partially addresses the failure scenario tests.
    - The `get_order_status` tool, which is a core requirement for this module, is not present in the provided code snippets.
    _Suggestions:_
      - Implement the `get_order_status` tool, ensuring it also utilizes `ToolContext.state` for session memory and provides structured output.
      - Explicitly demonstrate session state persistence across turns, ideally with a Redis integration as specified in the task description, beyond just within a single tool call.
      - Add more comprehensive failure scenario tests, including cases like product not found, database connection issues, and invalid input formats, to ensure robustness.
- **Integrate RAG Knowledge Base (eComBot v3)** (fail, 0.0/10)
    - The provided `ecombot/src/models.py` file only defines the LLM configuration and agent building function.
    - There is no evidence in the provided code snippet of ChromaDB integration, RAG implementation, or any knowledge base indexing.
    - The code does not show any mechanism for grounding responses in retrieved context or implementing a hallucination guard.
    - No test cases or related code for retrieval queries or hallucination detection were found.
    _Suggestions:_
      - Implement ChromaDB indexing for the product catalog and FAQ. This would typically involve a separate script or module to load data and create embeddings.
      - Integrate a retrieval mechanism within the agent's workflow to fetch relevant documents from ChromaDB based on user queries.
      - Develop a strategy for grounding agent responses using the retrieved context and implement a hallucination guard to prevent fabricated answers.
      - Create specific test cases to validate correct retrieval, graceful fallback for unknown queries, and effective hallucination detection.
- **Implement LiteLLM Model Routing (eComBot v4)** (fail, 2.0/10)
    - The `ecombot/src/models.py` file defines a `LiteLlm` instance, but it uses a single hardcoded model (`openrouter/google/gemini-2.5-flash`).
    - There is no logic implemented for routing different types of queries (e.g., simple FAQ vs. complex complaints) to different models.
    - There is no explicit configuration or logic for automatic fallback to a secondary provider (like OpenRouter) if the primary model fails.
    - Only one provider (OpenRouter via `openrouter/google/gemini-2.5-flash`) appears to be configured, not at least two as required (e.g., OpenAI + OpenRouter).
    _Suggestions:_
      - Implement a function or class within `src/models.py` that takes the query intent or complexity as input and dynamically selects the appropriate LiteLLM model string (e.g., `gpt-4o-mini` for simple, `gpt-4o` for complex).
      - Configure LiteLLM with multiple providers (e.g., OpenAI and OpenRouter) and explore LiteLLM's built-in fallback mechanisms or implement custom retry logic with provider switching.
      - Update the `get_llm` function or create a new one to encapsulate the routing and fallback logic, ensuring that `build_agent` can utilize this dynamic model selection.
- **Integrate FastMCP External APIs (eComBot v5)** (fail, 0.0/10)
    - The provided `ecombot/src/models.py` file does not contain any FastMCP integration code.
    - There are no definitions for mock servers, tool functions, or error handling logic related to FastMCP.
    - The file primarily focuses on LLM configuration and agent building, which is not directly related to the FastMCP integration task.
    _Suggestions:_
      - Create new files or modify existing ones (e.g., `ecombot/src/tools/order_tools.py`, `ecombot/src/services/mcp_orders.py`) to define the FastMCP mock servers and tool functions.
      - Implement the `get_order_status`, `cancel_order`, `get_invoice`, and `check_stock` functions, ensuring they interact with the FastMCP mock servers.
      - Add comprehensive error handling within these tool functions to gracefully manage timeouts, 404s, 500 errors, and invalid IDs as specified in the requirements.
- **Develop Multi-Agent Architecture (eComBot v6)** (partial, 4.0/10)
    - The `build_agent` function in `src/models.py` provides a reusable way to create `LlmAgent` instances, which is a good foundation for a multi-agent system.
    - The `support_instructions_v3.txt` file shows an evolution of the Support Agent's capabilities, indicating a progressive build, but the multi-agent architecture itself is not yet implemented.
    - The provided code snippets do not show the actual implementation of an Orchestrator agent, nor the distinct Sales Agent, which are core requirements for this module.
    - There is no explicit routing logic or delegation mechanism visible in the provided files to demonstrate the 'Planner–Executor' pattern.
    _Suggestions:_
      - Implement the Orchestrator agent responsible for classifying user intent and delegating tasks to either the Support Agent or the new Sales Agent.
      - Create a distinct `sales_agent.py` (or similar) with its own instructions and tools, separate from the Support Agent.
      - Introduce a routing mechanism (e.g., using ADK's `AgentGroup` or custom logic) to direct user queries to the appropriate agent based on the Orchestrator's decision.
      - Ensure that the `build_agent` function is utilized to instantiate all three agents (Orchestrator, Support, Sales) with their respective instructions and tools.
- **Build Generative UI (eComBot v7)** (fail, 0.0/10)
    - The provided `models.py` file does not contain any code related to building a Gradio chat interface or any UI components.
    - There is no evidence of real-time streaming, agent routing display, or graceful fallback for unstructured output in the given code snippet.
    - The file focuses solely on LLM configuration and agent instantiation, which are foundational but not directly part of the UI task.
    - The task specifically requires a `ui/app.py` file, which is not present in the provided relevant files.
    _Suggestions:_
      - Create a `ui/app.py` file as suggested in the repository structure to implement the Gradio interface.
      - Implement the Gradio chat interface, including components for product cards, order status cards, agent routing trace, RAG source tags, and LiteLLM model badge.
      - Ensure real-time streaming of agent responses is integrated into the Gradio UI.
- **Implement Voice Interface (eComBot v8)** (fail, 0.0/10)
    - The provided `ecombot/src/models.py` file does not contain any code related to implementing a voice interface.
    - There are no references to STT (faster-whisper), TTS (Piper), or LiveKit Agents in the provided code.
    - The code focuses solely on LLM configuration and agent building, which is foundational but not specific to voice integration.
    - The expected outcomes for this task, such as real-time STT/TTS, multi-language support, latency measurement, and interruption handling, are not addressed by the given file.
    _Suggestions:_
      - Review the project requirements for Module 8 and identify the specific components needed for a voice interface (STT, TTS, LiveKit integration).
      - Create new files or modify existing ones (e.g., `ecombot/src/voice/pipeline.py` as suggested in the repository structure) to implement the voice processing logic.
      - Integrate the voice pipeline with the existing agent architecture, ensuring that transcribed speech is fed to the Orchestrator and agent responses are converted to speech.
- **Upgrade Sales Agent with ReAct (eComBot v9)** (fail, 0.0/10)
    - The provided `models.py` file only contains model configuration and agent building utilities.
    - There is no code related to the Sales Agent's implementation, ReAct loop, or reflection mechanism.
    - The file does not show any UI components for a collapsible reasoning panel.
    - The core logic for implementing ReAct reasoning and reflection is entirely missing from the provided snippet.
    _Suggestions:_
      - Provide the `sales_agent.py` file or any other relevant files that implement the ReAct reasoning loop for the Sales Agent.
      - Demonstrate how the agent identifies budget, filters the catalog, compares specs, and recommends products within the Sales Agent's logic.
      - Show how the agent reflects and adjusts its recommendations upon rejection, as well as the implementation of the collapsible 'Agent Reasoning' panel in the UI.
- **Add Observability and Evaluation (eComBot v10)** (fail, 0.0/10)
    - The provided `models.py` file does not contain any explicit configuration or integration for LangSmith tracing.
    - There is no evidence of PromptFoo test cases or their integration within the provided code snippet.
    - The code does not show any implementation for an admin panel or the display of cost per session.
    - The `LiteLlm` model is used, which is a good start for model routing, but the specific routing logic for different complexities (e.g., `gpt-4o-mini` for FAQ, `gpt-4o` for complex flows) is not present in this file.
    _Suggestions:_
      - Integrate LangSmith by configuring the `LANGCHAIN_TRACING_V2` and `LANGCHAIN_API_KEY` environment variables and ensuring ADK agents are properly instrumented for tracing.
      - Create a `promptfoo.yaml` file in the `evals/` directory with at least 10 test cases covering the specified scenarios (order lookup, cancellation, product discovery, RAG, guardrails, etc.).
      - Implement the logic for model routing based on query complexity within `get_llm()` or a similar function, as outlined in Module 4.
      - Develop the Gradio UI components for the hidden admin panel to display live logs, eval results, and cost per session, and ensure it can be toggled.

## Code Quality
- **Overall:** 8.7/10
- Readability: 9.0/10
- Modularity: 8.5/10
- Naming: 8.5/10
  - Findings:
    - ecombot/demo.py uses clear and descriptive function and variable names, with helpful docstrings and comments explaining version differences and usage instructions.
    - The code in demo.py is well modularized, separating concerns such as console helpers, ADK ask helper, per-version config, and the REPL loop for each version.
    - Naming conventions are mostly consistent and follow Python standards (snake_case for functions and variables, PascalCase for classes if any).
    - Some functions in demo.py start with underscores indicating internal use, which is good for encapsulation.
    - In src/tools/order_tools.py, functions and variables are well named, but the file is truncated and the last function cancel_order is incomplete, which affects completeness assessment.
  - Suggestions:
    - Add more inline comments in complex functions like _run_version to explain the flow, especially around environment variable handling and dynamic imports.
    - Split demo.py into smaller modules if it grows further, for example separating REPL logic and version configuration into separate files.
    - Ensure all files are complete and functions fully implemented before review (e.g., complete cancel_order in order_tools.py).
    - Consider adding type hints to all functions for better clarity and static analysis support.
    - Use consistent docstring style across all modules and functions, and add module-level docstrings where missing.

## Security
- Severity: medium
  - Issues:
    - Possible SELECT * FROM in ecombot/src/tools/order_tools.py:136
    - Possible hardcoded secret in ecombot/src/config/settings.py:4
    - Exposed credentials or API keys: Default empty string for PG_PASSWORD and REDIS_PASSWORD in ecombot/src/config/settings.py:10,16
  - Suggestions:
    - Replace 'SELECT *' with explicit column names in SQL queries (e.g., in ecombot/src/tools/order_tools.py:136) to prevent exposing unnecessary data and to make the query more robust to schema changes.
    - Ensure all sensitive credentials (like database passwords) are always loaded from environment variables and do not have default hardcoded values, even empty strings. Remove `default_factory=lambda: os.getenv("PG_PASSWORD", "")` and `default_factory=lambda: os.getenv("REDIS_PASSWORD", "")` and instead make these fields required or raise an error if not set, to prevent accidental deployment with empty passwords.
    - Review the `dotenv` usage to ensure `.env` files are not committed to version control and are handled securely in deployment environments.
    - Implement proper error handling and logging for database operations. While `try...except Exception` catches errors, specific exception types should be caught where possible, and sensitive details from exceptions should not be logged or exposed to users.
    - Consider using a dedicated secrets management service for production environments instead of `.env` files for critical credentials.

## Summary
## Project Review Summary

This submission shows a promising foundation in agent architecture and code quality, but significant portions of the project remain unimplemented, resulting in an overall score of 2.71/10.

**Strongest Areas:**

- **Code Quality (8.7/10):** Your code is genuinely well-written — clean abstractions like `build_agent`, consistent naming conventions, and thoughtful modularization in `demo.py` demonstrate real software craftsmanship that will serve you well throughout this course.
- **eComBot v1 (8.5/10):** The basic agent setup is solid. Your use of `support_instructions_v1.txt` to clearly define agent scope and your selection of a cost-effective LLM reflect good production-minded thinking.

**Most Important Areas for Improvement:**

- **Complete the core deliverables:** Tasks v3 through v10 are largely missing or scored near zero. The evaluator repeatedly found only `models.py` where entire feature modules were expected — RAG integration, FastMCP, voice interface, and observability all need dedicated implementation files.
- **Address security vulnerabilities:** Hardcoded default credentials in `settings.py` and `SELECT *` queries are medium-severity issues that must be resolved before any production consideration.

You've clearly grasped the foundational concepts — the code you *did* write is clean and thoughtful. Now it's time to build on that foundation and bring the remaining modules to life. You've got this! 💪